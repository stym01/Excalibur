#include<iostream>
using namespace std;

int gcdIterative(int a, int b) {
    while (b != 0) {
        int temp = a;
        a = b;
        b = temp % b;
    }
    return a;
}

int gcdRecursive(int a, int b) {
    if (b == 0)
        return a;
    return gcdRecursive(b, a % b);
}

int main() {
    int a, b;
    cin >> a >> b;
    
   
    int gcd = gcdIterative(a, b);  
   
    cout << gcd << endl;

    return 0;
}

/*
Test cases:

1.
IP: 
10 15
OP:
5

2.
IP: 
7 13
OP:
1

3.
IP: 
0 5
OP:
5

4.
IP: 
20 20
OP:
20

5.
IP: 
1 999
OP:
1

6.
IP: 
-12 18
OP:
6

7.
IP: 
36 6
OP:
6

8.
IP: 
270 192
OP:
6
*/
