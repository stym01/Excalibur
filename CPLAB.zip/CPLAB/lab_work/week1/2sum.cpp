#include<iostream>
#include<unordered_map>
#include<vector>
#include<algorithm>

using namespace std;

void bruteSol(vector<int>& arr, int n, int x, int& a, int& b) {
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (arr[i] + arr[j] == x) {
                a = i;
                b = j;
                return;
            }
        }
    }
    a = -1, b = -1;
}

void EffSolOne(vector<int>& arr, int n, int x, int& a, int& b) {
    unordered_map<int, int> hash;
    for (int i = 0; i < n; i++) {
        int leftVal = x - arr[i];
        if (hash.find(leftVal) != hash.end()) {
            a = hash[leftVal];
            b = i;
            return;
        }
        hash[arr[i]] = i;
    }
    a = -1, b = -1;
}

void EffSolTwo(vector<int>& arr, int n, int x, int& a, int& b) {
    vector<pair<int, int>> vecTemp(n);
    for (int i = 0; i < n; i++) {
        vecTemp[i].first = arr[i];
        vecTemp[i].second = i;
    }
    sort(arr.begin(), arr.end());
    int i = 0, j = n - 1;
    while (i < j) {
        if (vecTemp[i].first + vecTemp[j].first == x) {
            a = vecTemp[i].second;
            b = vecTemp[j].second;
            return;
        }
        else if (arr[i] + arr[j] < x) {
            i++;
        }
        else {
            j--;
        }
    }
    a = -1;
    b = -1;
}

int main() {
    int n, x;
    vector<int> arr;
    
  
    cin >> n;
    for (int i = 0; i < n; i++) {
        int temp;
        cin >> temp;
        arr.push_back(temp);
    }
    cin >> x;

    int a, b;
    bruteSol(arr, n, x, a, b);
    cout << "Brute Force Solution: " << a << ", " << b << endl;

    EffSolOne(arr, n, x, a, b);
    cout << "Efficient Solution One: " << a << ", " << b << endl;

    EffSolTwo(arr, n, x, a, b);
    cout << "Efficient Solution Two: " << a << ", " << b << endl;

    return 0;
}

/*
Test Cases:


6
1 2 3 4 5 6
10



5
-1 2 4 7 5
6



4
-1 -2 -3 -4
-5



3
1 2 3
7



4
4 4 4 4
8



2
5 5
10



6
10 2 8 1 4 3
9






0
0




*/
