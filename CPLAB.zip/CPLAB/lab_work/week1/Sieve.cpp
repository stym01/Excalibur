#include<iostream>
using namespace std;

void primeSieveMethod(int n, bool prime[]) {
    for (int ind = 2; ind <= n; ind++)
        prime[ind] = true;

    prime[0] = prime[1] = false;

    for (int num = 2; num * num <= n; num++) {
        if (prime[num]) {
            for (int numMul = num * num; numMul <= n; numMul += num) {
                prime[numMul] = false;
            }
        }
    }
}

int main() {
    int m, n;
    cin >> m >> n;

    if (m < 0 || n < 0 || m > n) {
        cout << -1;
        return 0;
    }

    bool prime[n + 1];
    primeSieveMethod(n, prime);

    for (int num = m; num <= n; num++) {
        if (prime[num])
            cout << num << " ";
    }
    return 0;
}

/*
Test cases:

1. 
Input: 
-1 20
Output: 
-1

2. 
Input: 
1 -20
Output: 
-1

3. 
Input: 
0 20
Output: 
2 3 5 7 11 13 17 19 

4. 
Input: 
20 19
Output: 
-1

5. 
Input: 
1 1
Output: 

6. 
Input: 
1 20
Output: 
2 3 5 7 11 13 17 19

7. 
Input: 
30 50
Output: 
31 37 41 43 47 

8. 
Input: 
100 1000
Output: 
101 103 107 109 113 127 131 137 139 149 151 157 163 167 173 179 181 191 193 197 199 211 223 227 229 233 239 241 251 257 263 269 271 277 281 283 293 307 311 313 317 331 337 347 349 353 359 367 373 379 383 389 397 401 409 419 421 431 433 439 443 449 457 461 463 467 479 487 491 499 503 509 521 523 541 547 557 563 569 571 577 587 593 599 601 607 613 617 619 631 641 643 647 653 659 661 673 677 683 691 701 709 719 727 733 739 743 751 757 761 769 773 787 797 809 811 821 823 827 829 839 853 857 859 863 877 881 883 887 907 911 919 929 937 941 947 953 967 971 977 983 991 997
*/
