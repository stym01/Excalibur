#include <bits/stdc++.h>
using namespace std;

struct Node {
    int val;
    Node* next;
    Node(int val, Node* next) : val(val), next(next) {}
};

void addedge(int src, int des, vector<Node*>& adj) {
    Node* newvertex = new Node(des, adj[src]);
    adj[src] = newvertex;
}

vector<Node*> createGraph(int n, vector<pair<int, int>>& edges) {
    vector<Node*> adj(n, NULL);
    for (int i = 0; i < edges.size(); i++) {
        int src = edges[i].first, des = edges[i].second;
        addedge(src, des, adj);
    }
    return adj;
}

bool detectCycle(int node, vector<int>& vis, vector<int>& recStack, vector<Node*>& adj) {
    if (!vis[node]) {
        vis[node] = true;
        recStack[node] = true;

        Node* temp = adj[node];
        while (temp) {
            int val = temp->val;
            if (!vis[val] && detectCycle(val, vis, recStack, adj))
                return true;
            else if (recStack[val])
                return true;
            temp = temp->next;
        }
    }
    recStack[node] = false;
    return false;
}

bool solve(int n, vector<pair<int, int>>& edges) {
    vector<Node*> adj = createGraph(n, edges);
    vector<int> vis(n, false);
    vector<int> recStack(n, false);

    for (int i = 0; i < n; i++) {
        if (!vis[i] && detectCycle(i, vis, recStack, adj))
            return true;
    }
    return false;
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n, m;
        cin >> n >> m;
        vector<pair<int, int>> edges(m);
        for (int i = 0; i < m; i++) {
            int src, des;
            cin >> src >> des;
            edges[i] = {src, des};
        }
        cout << (solve(n, edges) ? "YES" : "NO") << endl;
    }
    return 0;
}

/*
Input:
5
4 4
0 1
1 2
2 3
3 1     

4 3
0 1
1 2
2 3     

5 5
0 1
1 2
2 0
3 4
4 3     

3 0
        

2 2
0 1
1 0     


Output:
YES
NO
YES
NO
YES
*/
