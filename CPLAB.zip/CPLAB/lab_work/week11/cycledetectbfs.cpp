#include <bits/stdc++.h>
using namespace std;

struct Node {
    int val;
    Node* next;
    Node(int val, Node* next) : val(val), next(next) {}
};

void addedge(int src, int des, vector<Node*>& adj) {
    Node* newvertex = new Node(des, adj[src]);
    adj[src] = newvertex;
}

vector<Node*> createGraph(int n, vector<pair<int, int>>& edges) {
    vector<Node*> adj(n, NULL);
    for (int i = 0; i < edges.size(); i++) {
        int src = edges[i].first, des = edges[i].second;
        addedge(src, des, adj);
    }
    return adj;
}

bool detectCycleBFS(int start, vector<Node*>& adj, vector<bool>& globalVisited) {
    int n = adj.size();
    queue<pair<int, vector<bool>>> q;

    vector<bool> initialPath(n, false);
    initialPath[start] = true;
    globalVisited[start] = true;

    q.push({start, initialPath});

    while (!q.empty()) {
        int node = q.front().first;
        vector<bool> path = q.front().second;
        q.pop();

        Node* temp = adj[node];
        while (temp) {
            int next = temp->val;
            if (path[next]) {
                
                return true;
            }

            if (!globalVisited[next]) {
                globalVisited[next] = true;
                vector<bool> newPath = path;
                newPath[next] = true;
                q.push({next, newPath});
            }

            temp = temp->next;
        }
    }

    return false;
}

bool solve(int n, vector<pair<int, int>>& edges) {
    vector<Node*> adj = createGraph(n, edges);
    vector<bool> globalVisited(n, false);

    for (int i = 0; i < n; i++) {
        if (!globalVisited[i]) {
            if (detectCycleBFS(i, adj, globalVisited))
                return true;
        }
    }
    return false;
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n, m;
        cin >> n >> m;
        vector<pair<int, int>> edges(m);
        for (int i = 0; i < m; i++) {
            int src, des;
            cin >> src >> des;
            edges[i] = make_pair(src, des);
        }
        cout << (solve(n, edges) ? "YES" : "NO") << endl;
    }
    return 0;
}

/*
Input:
5
4 4
0 1
1 2
2 3
3 1     

4 3
0 1
1 2
2 3     

5 5
0 1
1 2
2 0
3 4
4 3     

3 0
        

2 2
0 1
1 0     


Output:
YES
NO
YES
NO
YES
*/
