#include <bits/stdc++.h>
using namespace std;
void dfs(int row,int col,vector<vector<int>>& grid,vector<vector<bool>>& vis,vector<pair<int,int>>& dir,int n,int m){
    vis[row][col]=true;
    cout<<"("<<row<<","<<col<<")"<<" ";
    
    for(auto& val:dir){
        int r=row+val.first,c=col+val.second;
        if(r>=0 && c>=0 && r<n && c<m && !vis[r][c] && grid[r][c]){
            dfs(r,c,grid,vis,dir,n,m);
        }
    }
}
int solve(vector<vector<int>>& grid){
    int countIslands=0;
    int n=grid.size();
    int m=grid[0].size();
    vector<vector<bool>> vis(n,vector<bool>(m,false));
    vector<pair<int,int>> dir={{1,0},{0,1},{-1,0},{0,-1},{-1,-1},{1,1},{-1,1},{1,-1}};
    for(int row=0;row<n;row++){
        for(int col=0;col<m;col++){
            if(!vis[row][col] && grid[row][col]){
                dfs(row,col,grid,vis,dir,n,m);
                cout<<endl;
                countIslands++;

            }
        }
    }
    return countIslands;
}
int main(){
   
        int n,m;                                                                 
        cin>> n>> m;
        vector<vector<int>> grid(n,vector<int>(m));
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                cin>>grid[i][j];
            }
            
        }
        cout<<solve(grid)<<endl;
    
    return 0;
}
/* testcases
IP:
5 5
1 0 1 1 1
0 0 0 1 1
0 0 0 0 0
1 1 1 1 1
1 1 1 1 1
OP:
(0,0)
(0,2) (0,3) (1,3) (1,4) (0,4)
(3,0) (4,0) (4,1) (4,2) (4,3) (4,4) (3,4) (3,3) (3,2) (3,1)
3

IP:
2 2
0 0
1 1
OP:
(1,0) (1,1)
1

IP:
3 3
1 0 0
0 0 1
1 0 1
OP:
(0,0)
(1,2) (2,2)
(2,0)
3

IP:
4 4
1 0 1 1
0 1 0 1
0 0 0 0
0 0 0 0
OP:
(0,0) (1,1) (0,2) (0,3) (1,3)
1


IP:
1 1
1
OP:
(0,0)
1


*/

                                                                                 
                                                                                  
                                                                                 