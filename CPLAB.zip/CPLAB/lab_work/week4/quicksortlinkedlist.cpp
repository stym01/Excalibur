#include<bits/stdc++.h>
using namespace std;

class ListNode {
public:
    int val;
    ListNode* next;
    ListNode() {
        this -> val = 0;
        this -> next = nullptr;
    }

    ListNode(int value) {
        this -> val = value;
        this -> next = nullptr;
    }
};

ListNode* findTail(ListNode* head) {
            while (head && head->next)
                head = head->next;
            return head;
        }
    
ListNode* partition(ListNode* head, ListNode* tail) {
            ListNode* curr = head;
            ListNode* pivot = tail;
            ListNode* marker = head;
    
            while (curr != tail) {
                if (curr->val <= pivot->val) {
                    swap(curr->val, marker->val);
                    marker = marker->next;
                }
                curr = curr->next;
            }
            swap(marker->val, tail->val);
            return marker; 
        }
    
void quickSort(ListNode* head, ListNode* tail) {
            if (!head || head == tail || !tail)
                return;
    
            // Find pivot using partition
            ListNode* pivot = partition(head, tail);
    
            // Sort left part
            if (head != pivot) {
                ListNode* prev = head;
                while (prev->next != pivot)
                    prev = prev->next;
                quickSort(head, prev);
            }
    
            // Sort right part
            if (pivot != tail && pivot->next)
                quickSort(pivot->next, tail);
        }
    
ListNode* sortList(ListNode* head) {
            if (!head || !head->next)
                return head;
            ListNode* tail = findTail(head);
            quickSort(head, tail);
            return head;
        }
    
ListNode* input(int n) {
            ListNode* head = nullptr;
            ListNode* curr = nullptr;
            for(int i = 0 ; i < n ; i++) {
                int val;
                cin >> val;
                ListNode* temp = new ListNode(val);
                if(head == nullptr) {
                    head = temp;
                    curr = head;
                } else {
                    curr -> next = temp;
                    curr = curr -> next;
                }
            }
            return head;
        } 

void printList(ListNode* head) {
    ListNode* curr = head;
    while(curr) {
        cout << curr -> val << " ";
        curr = curr -> next;
    }
    return;
}

int main() {
    int t;
    cin >> t;
    while(t--) {
        int n;
        cin >> n;
        ListNode* head = nullptr;
        head = input(n);
        ListNode* tail = findTail(head);
        sortList(head);
        printList(head);
        cout << endl;
    }
    return 0;
}



/*
Test cases:

INPUT:
8
5
5 3 8 2 7

4
1 4 3 2

6
9 7 8 6 5 4

3
3 1 2

6
6 6 6 6 6 6

7
10 20 30 40 50 60 70

5
15 25 35 45 55

8
1 2 3 4 5 6 7 8


OUTPUT:
2 3 5 7 8 
1 2 3 4 
4 5 6 7 8 9 
1 2 3 
6 6 6 6 6 6 
10 20 30 40 50 60 70 
15 25 35 45 55 
1 2 3 4 5 6 7 8 
*/

