#include <bits/stdc++.h>

using namespace std;
int findIndex(vector<int>& arr,int target){
    int n=arr.size();
    int low=0,high=n-1;
    while(low<=high){
        int mid=low+(high-low)/2;
        if(arr[mid]==target) return mid;
        if(arr[mid]>=arr[low]){
            if(target>=arr[low] && target<arr[mid]){
                high=mid-1;
            }
            else{
                low=mid+1;
            }
        }
        else{
            if(target>arr[mid] && target<=arr[high]){
                low=mid+1;
            }
            else{
                high=mid-1;
            }
        }
    }
    return -1;
}
int main(){
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        vector<int> arr(n);
        for(int i=0;i<n;i++){
            cin>>arr[i];
        }
        int target;
        cin>>target;
        cout<<findIndex(arr,target)<<endl;
    }
    return 0;
}
// testcases
/*
7
6
4 5 6 1 2 3
2

5
5 1 2 3 4
5

5
2 3 4 5 1
1

1
3
10

2
5 4 
4

2
1 2
1

8
1 2 3 4 5 6 7 8
4


*/