#include<iostream>
#include<vector> 
#include<stack>
using namespace std;

vector<int> solve(vector<int>& stockPrice){
    int n = stockPrice.size();
    vector<int> ans(n);
    stack<int> s;

    for(int i = 0; i < n; i++) {
        while(!s.empty() && stockPrice[s.top()] <= stockPrice[i]) {
            s.pop();
        }
        if(s.empty()) ans[i] = i + 1;
        else ans[i] = i - s.top();
        s.push(i);
    }
    return ans;
}

int main() {
    int t;
    cin >> t;  
    while(t--) {
        int n;
        cin >> n; 
        vector<int> stockPrice(n);
        for(int i = 0; i < n; i++) {
            cin >> stockPrice[i];  
        }
        vector<int> ans = solve(stockPrice);
        
        for(int i = 0; i < n; i++) {
            cout << ans[i] << " ";  
        }
        cout << endl;
    }
    return 0;
}

/*
Test cases:

INPUT:
8
6
100 80 60 70 60 75
5
10 4 5 90 120
3
30 30 30
4
10 20 30 40
4
40 30 20 10
6
10 20 30 10 40 30
5
10 20 30 10 40
7
100 90 80 70 60 50 40

OUTPUT:
1 1 1 2 1 4 
1 1 2 4 5 
1 1 1 
1 2 3 4 
1 1 1 1 
1 2 3 1 5 2 
1 2 3 1 5 
1 1 1 1 1 1 1 
*/

