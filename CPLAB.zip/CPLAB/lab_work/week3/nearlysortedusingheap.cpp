#include<bits/stdc++.h>
using namespace std;
void solve(vector<int>& arr,int k){
    priority_queue<int,vector<int>,greater<int>> q;
    for(int i=0;i<=k;i++){
        q.push(arr[i]);
    }
    int ind=0;
    for(int i=k+1;i<arr.size();i++){
        arr[ind++]=q.top();
        q.pop();
        q.push(arr[i]);
    }
    while(!q.empty()){
        arr[ind++]=q.top();
        q.pop();
    }
}
int main(){
   int t;
   cin>>t;
   while(t--){
    int n,k;
    cin>>n>>k;
    vector<int> arr(n);
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    solve(arr,k);
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
   }
    return 0;
}

/*
Test cases:

/*
ip:-


12
7 2
1 4 5 2 3 7 6

7 3
2 1 4 3 6 5 7

7 1
2 1 4 3 6 5 7

7 6
7 6 5 4 3 2 1

7 1
1 2 3 4 5 6 7
 
7 5 
3 5 8 2 1 9 4

5 5
1 2 3 4 5 

5 2
-3 -5 -8 -1 -2

5 3
-1 -5 0 2 1
 
5 0 
1 2 3 4 5

4 2
3 2 1 4

1 1
2


op:
1 2 3 4 5 6 7 
1 2 3 4 5 6 7 
1 2 3 4 5 6 7 
1 2 3 4 5 6 7 
1 2 3 4 5 6 7
1 2 3 4 5 8 9 
1 2 3 4 5 
-8 -5 -3 -2 -1 
-5 -1 0 1 2
1 2 3 4 5 
3 5 7 8 9
2

*/