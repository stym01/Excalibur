#include <bits/stdc++.h>
using namespace std;

void merge(vector<int>& arr, int low, int mid, int high) {
    vector<int> temp;
    int i = low, j = mid + 1;
    while (i <= mid && j <= high) {
        if (arr[i] <= arr[j]) {
            temp.push_back(arr[i]);
            i++;
        } else {
            temp.push_back(arr[j]);
            j++;
        }
    }
    while (i <= mid) {
        temp.push_back(arr[i]);
        i++;
    }
    while (j <= high) {
        temp.push_back(arr[j]);
        j++;
    }
    for (i = low; i <= high; i++) {
        arr[i] = temp[i - low];
    }
}

void mergesort(vector<int>& arr, int low, int high) {
    if (low >= high) return;
    int mid = low + (high - low) / 2;
    mergesort(arr, low, mid);
    mergesort(arr, mid + 1, high);
    merge(arr, low, mid, high);
}

void solve(vector<int>& arr, int k) {
    if(k==0) return;
    int n=arr.size();
    for(int i=0;i<n;i+=k){
        int low=i;
            int high=min(n-1,i+2*k-1);
            mergesort(arr,low,high);
    }
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n, k;
        cin >> n >> k;
        vector<int> arr(n);
        for (int i = 0; i < n; i++) {
            cin >> arr[i];
        }
        solve(arr, k);
        for (int i = 0; i < n; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
    return 0;
}

/*
Test cases:

/*
ip:-


12
7 2
1 4 5 2 3 7 6

7 3
2 1 4 3 6 5 7

7 1
2 1 4 3 6 5 7

7 6
7 6 5 4 3 2 1

7 1
1 2 3 4 5 6 7
 
7 5 
3 5 8 2 1 9 4

5 5
1 2 3 4 5 

5 2
-3 -5 -8 -1 -2

5 3
-1 -5 0 2 1
 
5 0 
1 2 3 4 5

4 2
3 2 1 4

1 1
2


op:
1 2 3 4 5 6 7 
1 2 3 4 5 6 7 
1 2 3 4 5 6 7 
1 2 3 4 5 6 7 
1 2 3 4 5 6 7
1 2 3 4 5 8 9 
1 2 3 4 5 
-8 -5 -3 -2 -1 
-5 -1 0 1 2
1 2 3 4 5 
3 5 7 8 9
2

*/