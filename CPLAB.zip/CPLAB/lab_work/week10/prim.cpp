#include <bits/stdc++.h>
using namespace std;

struct Node {
    int vertex;
    int key;
    int parent;
    Node(int vertex, int key) : vertex(vertex), key(key), parent(-1) {}
};

struct ListNode {
    int vertex;
    int weight;
    ListNode* next;
    ListNode(int vertex, int weight) : vertex(vertex), weight(weight), next(NULL) {}
};

bool visited[1000];

void heapify(int ind, Node* arr[], int size, int posInHeap[]) {
    int left = 2 * ind;
    int right = 2 * ind + 1;
    int smallest = ind;

    if (left <= size && arr[left]->key < arr[smallest]->key)
        smallest = left;
    if (right <= size && arr[right]->key < arr[smallest]->key)
        smallest = right;

    if (smallest != ind) {
        swap(posInHeap[arr[smallest]->vertex], posInHeap[arr[ind]->vertex]);
        swap(arr[smallest], arr[ind]);
        heapify(smallest, arr, size, posInHeap);
    }
}

Node* extract_min(Node* arr[], int& size, int posInHeap[]) {
    Node* top = arr[1];
    swap(posInHeap[arr[1]->vertex], posInHeap[arr[size]->vertex]);
    swap(arr[1], arr[size]);
    size--;
    heapify(1, arr, size, posInHeap);
    return top;
}

void decrease_key(Node* heap[], int ind, int val, int posInHeap[]) {
    heap[ind]->key = val;
    int parent = ind / 2;
    while (parent >= 1 && heap[parent]->key > heap[ind]->key) {
        swap(posInHeap[heap[parent]->vertex], posInHeap[heap[ind]->vertex]);
        swap(heap[parent], heap[ind]);
        ind = parent;
        parent = ind / 2;
    }
}

void addEdge(ListNode* adj[], int u, int v, int weight) {
    ListNode* newNode1 = new ListNode(v, weight);
    newNode1->next = adj[u];
    adj[u] = newNode1;

    ListNode* newNode2 = new ListNode(u, weight);
    newNode2->next = adj[v];
    adj[v] = newNode2;
}

pair<vector<vector<int>>, int> prims(int n, ListNode* adj[]) {
    Node* heap[n + 1];
    int size = n;
    int posInHeap[n + 1];

    for (int i = 1; i <= n; i++) {
        heap[i] = new Node(i, INT_MAX);
        posInHeap[i] = i;
    }

    heap[1]->key = 0;

    vector<vector<int>> ans;
    int sum = 0;

    while (size > 0) {
        Node* top = extract_min(heap, size, posInHeap);
        int u = top->vertex;
        visited[u] = true;

        if (top->parent != -1) {
            ans.push_back({top->parent, top->vertex});
            sum += top->key;
        }

        ListNode* head = adj[u];
        while (head) {
            int adjV = head->vertex;
            if (!visited[adjV] && heap[posInHeap[adjV]]->key > head->weight) {
                heap[posInHeap[adjV]]->parent = u;
                decrease_key(heap, posInHeap[adjV], head->weight, posInHeap);
            }
            head = head->next;
        }
    }

    return {ans, sum};
}

int main() {
    int n, e;
    cin >> n >> e;

    vector<vector<int>> edges(e, vector<int>(3));

    for (int i = 0; i < e; i++) {
        cin >> edges[i][0] >> edges[i][1] >> edges[i][2];
    }

    ListNode* adj[n + 1] = {NULL};

    for (int i = 0; i < e; i++) {
        int u = edges[i][0];
        int v = edges[i][1];
        int w = edges[i][2];
        addEdge(adj, u, v, w);
    }

    auto MST = prims(n, adj);

    for (auto edge : MST.first) {
        cout << edge[0] << "-" << edge[1] << endl;
    }

    cout << "MST Weight-" << MST.second << endl;
}
/*
Test Cases:
IP:
5 6
1 2 2
1 3 3
2 3 1
2 4 2
3 4 3
4 5 1
OP:
1-2
2-3
2-4
4-5
MST Weight-6


IP:
4 5
1 2 10
1 3 20
2 3 5
2 4 2
3 4 1
OP:
1-2
2-4
4-3
MST Weight-13


IP:
3 3
1 2 1
2 3 2
1 3 2
OP:
1-2
1-3
MST Weight-3


IP:
6 7
1 2 7
1 3 9
1 6 14
2 3 10
2 4 15
3 4 11
3 6 2
OP:
1-2
1-3
3-6
3-4
MST Weight-29


IP:
4 4
1 2 2
1 3 3
3 4 4
2 4 5
OP:
1-2
1-3
3-4
MST Weight-9




*/

