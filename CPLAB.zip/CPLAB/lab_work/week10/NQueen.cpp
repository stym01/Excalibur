#include <bits/stdc++.h>
using namespace std;

vector<int> x;
bool isPlace(int k){
    // int row = k;
    // int col = x[k];
    for(int j=k-1;j>=1;j--){
        if(x[k] == x[j] + k-j || x[k] == x[j] - k +j || x[k] == x[j]  ){
            return false;
        }
    }
   
    return true;
}

void next_value(int k , int n  ){
    while(1){
        x[k] = (x[k]+1)%(n+1);
        if(!x[k]) return;
        if(isPlace(k)){
            return;
        }
    }
}

void general_backtrack(int k , int n) {
    while(1){
        next_value(k,n);
        if(!x[k]) break;
        if(k==n) {
            for(int i=1;i<=n;i++){
                cout<<x[i]<<" ";
            }
            cout<<endl;
        }
        else{
            general_backtrack(k+1 , n);
        }
    }
}


int main(){
    int n ;
    cin>>n;
    x.resize(n+1,0);
    general_backtrack(1,n);

}
/*
Test Cases:
IP:4
OP:

2 4 1 3
3 1 4 2

IP:5
op:
1 3 5 2 4
1 4 2 5 3
2 4 1 3 5
2 5 3 1 4
3 1 4 2 5
3 5 2 4 1
4 1 3 5 2
4 2 5 3 1
5 2 4 1 3
5 3 1 4 2

IP:2
OP:

IP:6
OP:
2 4 6 1 3 5
3 6 2 5 1 4
4 1 5 2 6 3
5 3 1 6 4 2








*/

