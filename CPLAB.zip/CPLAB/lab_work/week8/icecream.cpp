#include <bits/stdc++.h>

using namespace std;
bool solve(vector<int>& arr){
    int curr5=0,curr10=0;
   
    int n=arr.size();
    for(int i=0;i<n;i++){
        if(arr[i]==5){
            curr5++;
        }
        else if(arr[i]==10){
            if(curr5==0) return false;
            curr5--;
            curr10++;

        }
        else if(arr[i]==20){
            if(curr5==0) return false;
            if(curr5<3 && curr10==0) return false;
            if(curr10>0){
                
                curr10--;
                curr5--;

            }
            else{
                curr5-=3;
            }

        }
    }
    return true;
}
int main(){
        int t;
        cin>>t;
        while(t--){
            int n;
            cin>>n;
            vector<int> arr(n);
            for(int i=0;i<n;i++){
                cin>>arr[i];
            }
            cout<< (solve(arr) ? "YES\n":"NO\n");
        }
       

        
    
    return 0;
}
/*
11
5
5 5 5 10 20

4
5 5 5 5

3
10 10 10

1
5

1
10

3
5 10 20

4
20 20 10 5

8
5 10 5 20 5 5 5 20


5
5 5 10 5 20

8
5 10 5 10 5 10 5 20

3
5 5 10
    


*/
