#include <bits/stdc++.h>
using namespace std;

vector<bool> convertTobits(int n) {
    vector<bool> arr(32);
    for (int i = 0; i < 32; i++) {
        if (n & (1 << i)) {
            arr[i] = 1;
        }
        else arr[i] = 0;
    }
    return arr;
}

int convertToInteger(vector<bool>& arr) {
    int n = 0;
    for (int i = 0; i < 32; i++) {
        if (arr[i]) {
            n = n | 1 << i;
        }
    }
    return n;
}

void solve(int n) {
    vector<bool> bits = convertTobits(n);
    int count = 0;
    for (int i = 0; i < 32; i++) {
        if (bits[i] && !bits[i + 1]) {
            swap(bits[i], bits[i + 1]);
            if (count >= 1) {
                for (int i = 0; i < count; i++) {
                    bits[i] = 1;
                }
            }
            break;
        }
        else if (bits[i]) {
            bits[i] = 0;
            count++;
        }
    }

    cout << convertToInteger(bits) << endl;
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        solve(n);
    }

    return 0;
}

/*
INPUT-
8
1

2

3

6

7

9

15

13948


OP-
2      
4       
5       
9       
11      
10      
23      
13967   
*/
