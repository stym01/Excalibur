#include<bits/stdc++.h>
using namespace std;

int findNSI(int n){
    int temp=n;
    int onecount=0;
    int bits=0;
    bool flag=false;

    while(temp){
        if(temp&1){
            onecount++;
            flag=true;
        }
        else if(flag){
            break;
        }
        bits++;
        temp>>=1;
    }

    // Swapping 1 and 0
    n |= (1 << bits);
    n &= ~(1 << (bits - 1));

    // Shifting remaining ones to end
    int mask = (1 << bits) - 1;
    n = n & (~mask);

    for(int i = 0; i < onecount - 1; i++){
        n |= (1 << i);
    }

    return n;
}

int main(){
    int t;
    cin >> t;
    while(t--){
        int n;
        cin >> n;
        cout << findNSI(n) << endl;
    }
    return 0;
}

/*
INPUT-
8
1

2

3

6

7

9

15

13948


OP-
2      
4       
5       
9       
11      
10      
23      
13967   
*/
