#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// int partition(vector<int>& arr, int left, int right, int pivotIndex) {
//     int pivotValue = arr[pivotIndex];
//     swap(arr[pivotIndex], arr[right]);
//     int storeIndex = left;
//     for (int i = left; i < right; i++) {
//         if (arr[i] < pivotValue) {
//             swap(arr[storeIndex], arr[i]);
//             storeIndex++;
//         }
//     }
//     swap(arr[storeIndex], arr[right]);
//     return storeIndex;
// }

// int medianOfMedians(vector<int>& arr, int left, int right) {
//     if (right - left + 1 <= 5) {
//         sort(arr.begin() + left, arr.begin() + right + 1);
//         return (left + right) / 2;
//     }

//     for (int i = left; i <= right; i += 5) {
//         int subRight = min(i + 4, right);
//         sort(arr.begin() + i, arr.begin() + subRight + 1);
//         swap(arr[(i + subRight) / 2], arr[(left + right) / 2]);
//     }
//     return medianOfMedians(arr, left, right);
// }

// int selectKthSmallest(vector<int>& arr, int left, int right, int k) {
//     if (left == right) {
//         return arr[left];
//     }

//     int pivotIndex = medianOfMedians(arr, left, right);
//     pivotIndex = partition(arr, left, right, pivotIndex);

//     if (k == pivotIndex) {
//         return arr[k];
//     } else if (k < pivotIndex) {
//         return selectKthSmallest(arr, left, pivotIndex - 1, k);
//     } else {
//         return selectKthSmallest(arr, pivotIndex + 1, right, k);
//     }
// }

// int kthSmallest(vector<int>& arr, int k) {
//     return selectKthSmallest(arr, 0, arr.size() - 1, k - 1);  
// }

// int main() {
//     int n, k;
    
//     cout << "Enter the number of elements in the array: ";
//     cin >> n;
    
//     vector<int> arr(n);
    
//     cout << "Enter the elements of the array: ";
//     for (int i = 0; i < n; i++) {
//         cin >> arr[i];
//     }
    
//     cout << "Enter the value of k (k-th smallest element): ";
//     cin >> k;
    
//     if (k > 0 && k <= n) {
//         cout << "The " << k << "-th smallest element is: " << kthSmallest(arr, k) << endl;
//     } else {
//         cout << "Invalid value of k" << endl;
//     }
    
//     return 0;
// }
#include <bits/stdc++.h>
using namespace std;

int partition(vector<int>& arr, int low, int high) {
    int pivot = arr[high];
    int i = low - 1;
    
    for (int j = low; j < high; j++) {
        if (arr[j] <= pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return i + 1;
}

int median_of_medians(vector<int>& arr, int low, int high) {
    if (high - low + 1 <= 5) {
        sort(arr.begin() + low, arr.begin() + high + 1);
        return arr[(low + high) / 2];
    }

    for (int i = low; i <= high; i += 5) {
        int end = min(i + 4, high);
        sort(arr.begin() + i, arr.begin() + end + 1);
    }

    vector<int> medians;
    for (int i = low; i <= high; i += 5) {
        int end = min(i + 4, high);
        medians.push_back(arr[(i + end) / 2]);
    }

    return median_of_medians(medians, 0, medians.size() - 1);
}

int select(vector<int>& arr, int low, int high, int k) {
    if (low == high) {
        return arr[low];
    }

    int pivot = median_of_medians(arr, low, high);
    
    int pivotIndex = -1;
    for (int i = low; i <= high; i++) {
        if (arr[i] == pivot) {
            pivotIndex = i;
            break;
        }
    }
    swap(arr[pivotIndex], arr[high]);
    
    int partitionIndex = partition(arr, low, high);
    
    if (k == partitionIndex) {
        return arr[k];
    } else if (k < partitionIndex) {
        return select(arr, low, partitionIndex - 1, k);
    } else {
        return select(arr, partitionIndex + 1, high, k);
    }
}

int main() 
{
    int t;
    cin >> t;
    while (t--) 
    {
        int n, k;
        cin >> n;
        
        vector<int> arr(n);
        for (int i = 0; i < n; i++) {
            cin >> arr[i];
        }
        cin >> k;
        
        if (k > 0 && k <= n) {
            cout << select(arr,0,n-1,k-1) << endl;
        } else {
            cout << -1000000 << endl;
        }
    }
    return 0;
}
/*

Testcases:-

ip:-


9
5
1 2 3 4 5
3

5
5 3 1 4 2
1

5
5 3 1 4 2
5

6
1 2 2 3 3 4
4

7
-3 -1 -7 0 2 10 5
2

8
10 9 8 7 6 5 4 3
6

10
15 3 20 2 5 7 9 11 13 17
7

3
10 20 30
0

3
10 20 30
4

op:-

3
1
5
3
-3
8
13
-1000000
-1000000

*/