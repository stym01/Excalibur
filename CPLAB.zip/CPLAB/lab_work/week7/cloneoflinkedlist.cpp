#include <bits/stdc++.h>

using namespace std;
struct ListNode{
    int val;
    ListNode* next;
    ListNode* random;
    ListNode(int value):val(value) ,next(nullptr),random(nullptr) {};
};
ListNode* insert(ListNode* temp,int val){
    if(!temp) return new ListNode(val);
  
    temp->next=new ListNode(val);
    temp=temp->next;
   
    return temp;
    
}
ListNode* solve(ListNode* head){
    
    unordered_map<ListNode*,ListNode*> strpointer;
    ListNode* temp=head;
    while(temp){
        strpointer[temp]=new ListNode(temp->val);
        temp=temp->next;
    }
    temp=head;
    while(temp){
        strpointer[temp]->next=strpointer[temp->next];
        strpointer[temp]->random=strpointer[temp->random];
        temp=temp->next;
    }
  
    return strpointer[head];
}
void printList(ListNode* head){
    if(!head) return;
    while(head){
        cout<<head->val<<" "<<head->random->val<<"--";
        head=head->next;
    }
}
int main(){
    int t;
    cin>>t;
    while(t--){
   unordered_map<int,ListNode*> strpointer;
   int n;
   cin>>n;
   ListNode* head=NULL,*temp=NULL;
   int val;
   for(int i=0;i<n;i++){
      cin>>val;
      if(!temp){
        head=insert(temp,val);
        temp=head;
        }
        else{
            temp=insert(temp,val);
        }
    strpointer[i]=temp;

   }
 
    for(int i=0;i<n;i++){
        cin>>val;
        if(val==-1) continue;
        strpointer[i]->random=strpointer[val];
    }
ListNode* newhead=solve(head);
printList(newhead);



    }
    return 0;
}
/*
testcases:
6
5
1 2 3 4 5
1 0 2 3 4

4
1 0 3 4
1 0 2 3

5
1 4 -1 -5 -10
4 3 1 1 1

1
-10
0

10
1 2 -10 3 4 2 1 3 4 5 
1 1 1 1 0 9 8 7 8 0

6
1 2 4 5 2 1
1 0 4 3 2 5


*/