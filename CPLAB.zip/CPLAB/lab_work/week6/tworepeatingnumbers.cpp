#include<bits/stdc++.h>

using namespace std;


void findOccur(vector<int>& nums, int n){

    int XOR=0;

    for(int i=1;i<=n;i++){
        XOR^=i;
    }
    for(int i=0;i<nums.size();i++){
        XOR^=nums[i];
    }

    int mask= XOR & ~(XOR-1);

    int num1=0;
    int num2=0;

    for(int i=1;i<=n;i++){
        if(i&mask){
            num1=num1^i;
        }
        else{
            num2= num2^i;
        }
    }

    for(int i=0;i<n+2;i++){
        if(nums[i]&mask){
            num1= num1^nums[i];
        }
        else{
            num2=num2^nums[i];
        }
    }

    cout<<"Two repeating are: "<<num1<<" "<<num2<<endl;
}
int main(){
   int t;
   cin>>t;
   while(t--){
    int n;
    cin>>n;


    vector<int> nums;

    for(int i=0;i<n+2;i++){
        int temp;
        cin>>temp;
        nums.push_back(temp);
    }

    
    findOccur(nums,n);
   }
   return 0;
}

/* 
5
8
1 4 5 6 3 2 4 2 8 7

2
2 1 1 2

8
1 4 5 6 3 2 8 7 2 7

4
4 3 2 1 1 4

3
3 1 2 2 1




*/