#include<bits/stdc++.h>
using namespace std;

int insertBits(int m, int n, int i, int j) {
    int allOnes = ~0;
    int left = allOnes << (j + 1);
    int right = (1 << i) - 1;
    int mask = left | right;
    
    m = m & mask;
    n = n << i;
    
    return m | n;
}
int main(){
    int t;
    cin>>t;
    while(t--){
        int m,n,i,j;
        cin>>m>>n>>i>>j;
    
        cout<<insertBits(m,n,i,j);
    
    }
    return 0;
  
}
/*
    10
    1042 21 2 6

    10 15 1 5

    0 31 0 5

    999 3 3 5

    500 10 4 8

    2024 21 31 28

    255 1 7 8

    255 1 0 1

    1023 15 4 8

    512 255 0 8

    





*/

