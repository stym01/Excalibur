#include <bits/stdc++.h>
using namespace std;

struct TreeNode {
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int val) : val(val), left(NULL), right(NULL) {}
};


void pathsum(TreeNode* root, int sum, vector<int>& path, bool& found) {
    if (!root) return;

    path.push_back(root->val);
    sum -= root->val;

    if (sum == 0) {
        for (int val : path)
            cout << val << " ";
        cout << endl;
        found = true;
    }

    pathsum(root->left, sum, path, found);
    pathsum(root->right, sum, path, found);

    path.pop_back();
}


TreeNode* input() {
    int val;
    cin>> val;
    TreeNode* root = new TreeNode(val);

    int x;
    if (!(cin >> x)) return root;
    if (x) root->left = input();

    int y;
    if (!(cin >> y)) return root;
    if (y) root->right = input();

    return root;
}

int main() {
        
        int inp;
        cin>> inp;
        
       if(inp){
        TreeNode* root = input();
        int k;
        cin>>k;
        vector<int> path;
        bool found = false;
        
      
        pathsum(root, k, path, found);
        if (!found) cout << "-1\n"; 
        

       } 
        else{
            TreeNode* root=NULL;
            int k;
            cin>>k;
            cout<< "-1\n";
        }

       

        
       
    
    return 0;
}

/*

Testcases:-

ip:-



1 40 1 10 1 20 0 0 0 1 30 0 1 10 1 -10 0 0 0 // random case (covering possibilities of same initial path taken upto different levels)
70

1 5 0 0 //only root
5

1 10 1 5 0 0 1 15 0 0 //full tree with 2 leaves
25

1 20 1 10 1 5 0 0 0 0 //left skewed tree (only left children)
35

1 3 0 1 4 0 1 5 0 1 6 0 0 //right skewed tree (only right children) 
18

1 10 1 5 0 0 1 5 0 0 //Tree with two distinct valid paths (different children with same value)
15

1 40 1 20 0 0 0 //no valid path
100

1 -10 1 5 1 -2 0 0 1 3 0 0 //no valid path with -ve sum
-9

1 2 1 -3 0 0 1 4 1 -2 0 0 //only one valid path with negative sum
-1

0 //empty tree
5

op:-

40 10 20 
40 30 
40 30 10 -10 

5

10 15

20 10 5

3 4 5 6

10 5 
10 5

-1

-1

2 -3

-1

*/
