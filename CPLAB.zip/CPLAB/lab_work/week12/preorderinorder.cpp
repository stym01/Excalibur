#include <bits/stdc++.h>
using namespace std;

struct TreeNode {
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int val) : val(val), left(NULL), right(NULL) {}
};

TreeNode* buildTree(int preStart, int inStart, int inEnd,
                          vector<int>& preorder, vector<int>& inorder,
                          unordered_map<int, int>& inorderidx) {
    if (inStart > inEnd) return NULL;
    
    TreeNode* root = new TreeNode(preorder[preStart]);
    int inRoot = inorderidx[root->val];
    int leftSize = inRoot - inStart;

    root->left = buildTree(preStart + 1, inStart, inRoot - 1, preorder, inorder, inorderidx);
    root->right = buildTree(preStart + leftSize + 1, inRoot + 1, inEnd, preorder, inorder, inorderidx);
    
    return root;
}

void postorder(TreeNode* root) {
    if (!root) return;
    postorder(root->left);
    postorder(root->right);
    cout << root->val << " ";
}

bool compareinorder(TreeNode* root, int& idx, vector<int>& inorder) {
    if (!root) return true;
    if (!compareinorder(root->left, idx, inorder)) return false;
    if (root->val != inorder[idx]) return false;
    idx++;
    if (!compareinorder(root->right, idx, inorder)) return false;
    return true;
}

bool comparepreorder(TreeNode* root, int& idx, vector<int>& preorder) {
    if (!root) return true;
    if (root->val != preorder[idx]) return false;
    idx++;
    if (!comparepreorder(root->left, idx, preorder)) return false;
    if (!comparepreorder(root->right, idx, preorder)) return false;
    return true;
}

void solve(vector<int>& inorder, vector<int>& preorder) {
    unordered_map<int, int> inorderidx;
    for (int i = 0; i < inorder.size(); i++) {
        inorderidx[inorder[i]] = i;
    }
    
    TreeNode* root = buildTree(0, 0, inorder.size() - 1, preorder, inorder, inorderidx);
    
    int idx = 0;
    bool check1 = compareinorder(root, idx, inorder);
    idx = 0;
    bool check2 = comparepreorder(root, idx, preorder);
    
    if (check1 && check2) postorder(root);
    else cout << "There is an error";
    
    cout << "\n";
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        vector<int> preorder(n), inorder(n);
        for (int i = 0; i < n; i++) cin >> preorder[i];
        for (int i = 0; i < n; i++) cin >> inorder[i];
        solve(inorder, preorder);
    }
    return 0;
}
/*
1
7
3 9 10 20 15 11 7
10 9 3 11 15 20 7           // normal

Output: 10 9 11 15 7 20 3

1
10                                  
1 2 4 6 5 3 7 8 9 10            // normal
4 2 5 6 1 3 8 9 7 10

Output: 4 5 6 2 9 8 10 7 3 1 

1
4 
3 5 6 7   // left skewed
7 6 5 3

Output: 7 6 5 3 

1
4
3 5 6 7   // right skewed
3 5 6 7

Output: 7 6 5 3 

1
2
5 4  // root with left child
4 5

Output: 4 5 

1
2
7 6     // root with right child
7 6

Output: 6 7 


1
7
4 2 1 5 3 6 7
1 2 5 4 6 3 7      Complete

Output: 1 5 2 6 7 3 4

1 
8
1 2 3 4 5 6 7 8
3 4 6 7 8 5 2 1   // (zig zag)

Output:  8 7 6 5 4 3 2 1
*/