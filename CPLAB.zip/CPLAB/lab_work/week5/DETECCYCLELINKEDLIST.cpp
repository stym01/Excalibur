#include<bits/stdc++.h>
using namespace std;
typedef struct Node
{
    int data;
    Node* next;
    Node(int x)
    {
        data=x;
        next=NULL;
    }
}Node;
Node* create(int n,int pos)
{
    Node *head=NULL,*temp=NULL,*pos_node=NULL;
    int val;
    cin>>val;
    head=new Node(val);
    temp=head;
    if(pos==0)pos_node=head;
    for(int i=1;i<n;i++)
    {
        cin>>val;
        temp->next=new Node(val);
        temp=temp->next;
        if(i==pos)pos_node=temp;
    }
    if(pos_node)temp->next=pos_node;
    return head;
}
bool isCyclic(Node* head)
{
    if(head->next==head)return true;
    else if(!head->next)return false;
    Node *slow=head;
    Node *fast=head;
    while(fast && fast->next)
    {
        slow=slow->next;
        fast=fast->next->next;
        if(slow==fast)return true;
    }
   
    return false;
}
int main()
{
    int t;
    cin>>t;
    while(t>0)
    {
        int n,pos;
        cin>>n>>pos;
        //op is 0 if not cyclic and 1 if cycle is present in linked list
        if(n<=0)cout<<0<<endl;
        else
        {
            Node* head=create(n,pos-1);
            bool ans=isCyclic(head);
            if(ans)cout<<1<<endl;
            else{cout<<0<<endl;}
        }
        t-=1;
    }
}

/*
Testcases:-

13
1 -1
5

1 1
5

4 -1
1 2 3 4

4 2
1 2 3 4

11 -1
1 2 3 4 5 6 7 8 9 10 11

5 4
1 2 3 4 5

3 1
1 2 3

10 -1
10 20 30 40 50 60 100 90 80 70

6 4
10 20 30 40 50 60

6 3
10 20 30 40 50 60

0 0

4 4
4 5 6 7

5 1
8 9 10 11 12

op:-

0
1
0
1
0
1
1
0
1
0
0
1
1

*/