#include<bits/stdc++.h>

using namespace std;

void printer(vector<int>& arr,int size){
    for(int i=1;i<size+1;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

void heapify(int ind,vector<int>& arr,int size){
    int left=2*ind;
    int right=2*ind+1;
    int largest=ind;

    if(left<size && arr[left]>arr[largest]){
        largest=left;
    }
    if(right<size && arr[right]>arr[largest]){
        largest=right;
    }
    if(largest!=ind){
        swap(arr[largest],arr[ind]);
        heapify(largest,arr,size);
    }


}

void buildHeap(vector<int>& arr,int size){
    for(int i=size/2;i>=1;i--){
        heapify(i,arr,size);
    }

}

int extract_max(vector<int>& arr,int& size){
    int top=arr[1];
    swap(arr[1],arr[size]);
    size-=1;
    heapify(1,arr,size);

    return top;
}

void insert(int elem,vector<int>& arr,int& size){
    arr[size+1]=elem;
    size+=1;

    int ind=size;

    int parent=ind/2;
    while(parent>=1){
        
        if(arr[parent]<arr[ind]){
            swap(arr[parent],arr[ind]);
        }
        ind=parent;
        parent=ind/2;
    }
}

void mergeHeaps(vector<int>& A, vector<int>& B,int& size1,int& size2){

    while(size2){
        int top= extract_max(B,size2);
        insert(top,A,size1);
    }
}

int main(){
    int m,n;
    cin>>m>>n;


    vector<int> A(m+n+1,0);
    vector<int> B(n+1,0);
    int size1=m;
    int size2=n;

    for(int i=1;i<m+1;i++){
        int temp;
        cin>>temp;
        A[i]=temp;
    }
    for(int i=1;i<n+1;i++){
        int temp;
        cin>>temp;
        B[i]=temp;
    }

    buildHeap(A,m+1);
    buildHeap(B,n+1);

    mergeHeaps(A,B,size1,size2);
    printer(A,size1);

}

/*
    7
    6
    9 8 12 36 4 6 7
    3 13 90 1 2 72

    7
    6
    9 8 12 36 42 44 98
    90 72 13 3 2 1

    7
    6
    1 2 3 4 5 6 7
    8 9 10 11 12 13 

    20 
    10
    1 2 3 4 5 6 7 1 2 3 4 5 6 7 1 2 3 4 5 6 
    90 72 13 3 2 1 -2 -4 -8 -20

    1
    1
    3
    5

    0
    1
    9

    1
    0
    3

    0
    0





*/
