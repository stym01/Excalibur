#include <bits/stdc++.h>
using namespace std;

int solve(vector<int>& v){
    int count=0;
    int negpro=1;
    int pospro=1;
    int maxneg=INT_MIN;
    int minpos=INT_MAX;
    bool check=false;
    for(int i=0;i<v.size();i++){
        if(v[i]>0) {
            minpos=min(minpos,v[i]);
            pospro*=v[i];
        }
        else if(v[i]<0){
            count++;
            negpro*=v[i];
            maxneg=max(maxneg,v[i]);
        }
        else check=true;
    }
    if(count==0) return check ? 0 : minpos;
    if(count%2==0){
        negpro=negpro/maxneg;
    }
    return negpro*pospro;
}

int main(){
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>> n;
        vector<int> v(n);
        for(int i=0;i<n;i++){
            cin>> v[i];
        }
        cout<<solve(v)<<endl;
    }
    return 0;
}

/*
Test Cases:

8
4
-1 2 3 4

5
-1 -2 3 4 5

5
-1 -2 -3 -4 5

3
0 0 0

4
-1 -2 -3 -4

5
1 2 3 4 0

6
-1 -2 -3 -4 -5 -6

3
1 -2 3


*/
