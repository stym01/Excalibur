#include<bits/stdc++.h>
using namespace std;

struct Node{
    string name;
    string code;
    Node* left;
    Node* right;
    int freq;

    Node(string name,int freq): name(name),freq(freq),left(NULL),right(NULL){}
};

struct comp{
    bool operator()(Node* a, Node* b){
        return a->freq > b->freq;
    }
};

Node* genHuff(vector<Node*>& nodes){
    priority_queue<Node*,vector<Node*>,comp> pq;

    for(auto node: nodes){
        pq.push(node);
    }

    while(pq.size()>1){
        Node* n1= pq.top();
        pq.pop();
        Node* n2= pq.top();
        pq.pop();

        Node* parent= new Node("",n1->freq+n2->freq);
        parent->left=n1;
        parent->right=n2;

        pq.push(parent);
    }
    return pq.top();
}

void genCode(Node* root,string code){
    if(root==NULL) return;

    if(root->left==NULL && root->right==NULL){
        root->code=code;
        return;
    }
    genCode(root->left,code+"0");
    genCode(root->right,code+"1");
}

void dispCode(vector<Node*>& nodes){
    for(auto i:nodes){
        cout<<i->name<<"-"<<i->code<<endl;
    }
}

int main(){
    int t;
    cin>>t;
    while(t--){
        int n;
    cin>>n;

    vector<Node*> nodes;

    for(int i=0;i<n;i++){
        string name;
        cin>>name;
        int fr;
        cin>>fr;

        Node* temp= new Node(name,fr);

        nodes.push_back(temp);
    }

    Node* root=genHuff(nodes);
    genCode(root,"");

    dispCode(nodes);
    }
    return 0;
}

/*
Test Cases:

5
5
apple 5
banana 9
cherry 12
date 13
elderberry 16

4
grape 7
honeydew 10
kiwi 15
lemon 30

3
mango 3
orange 6
pear 9

6
pineapple 10
quince 15
raspberry 30
strawberry 5
tomato 20
watermelon 40

2
avocado 20
blueberry 10


*/