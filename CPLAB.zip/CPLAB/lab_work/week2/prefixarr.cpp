#include<iostream>
#include<vector>
#include<limits.h>
using namespace std;

int solveMax(int n, int m) {
    vector<int> arr(n + 1, 0);
    int a, b;
    for (int i = 0; i < m; i++) {
        cin >> a >> b;
       
        if (a < 0 || b < 0 || a > b || b == n) {
            return -1;
        }
        arr[a] += 100;
        arr[b + 1] -= 100;
    }
    int maxi = arr[0];
    for (int i = 1; i < n; i++) {
        arr[i] += arr[i - 1];
        maxi = max(maxi, arr[i]);
    }
    return maxi;
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n, m;
        int a, b;
        cin >> n >> m;
        
        cout << solveMax(n, m) << endl;
    }
    return 0;
}

/*
INPUT:
8
5 2
1 3
2 4

5 1
2 6

5 3
1 3
2 4
3 5

1 1
0 0

5 1
-1 3

5 2
1 2
4 5

5 3
1 2
3 4
2 3

5 0

OUTPUT:
200

-1

300

100

-1

100

200

0
*/
