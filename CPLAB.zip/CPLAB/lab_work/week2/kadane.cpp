#include<iostream>
#include<vector>
#include<limits.h>
using namespace std;

int kadaneAlgorithm(const vector<int>& arr, int n) {
    int currSum = 0;
    int maxSum = INT_MIN;
    
    for (int i = 0; i < n; i++) {
        currSum += arr[i];
        maxSum = max(currSum, maxSum);
        
        if (currSum < 0) {
            currSum = 0;
        }
    }
    return maxSum;
}

int main() {
    int t;
    cin >> t;
   
    while (t--) {
        int n;
        cin >> n;
        
        if (n <= 0) {
            cout << -100000 << endl;
            continue;
        }
        
        vector<int> arr(n);
        for (int i = 0; i < n; i++) {
            cin >> arr[i];
        }
        
        cout << kadaneAlgorithm(arr, n) << endl;
    }
    
    return 0;
}

/*
INPUT:
8
5
-2 1 -3 4 -1 2 1 -5 4

4
-2 -3 -4 -1

1
5

0

6
1 -2 3 4 -1 2

3
0 0 0

5
1 2 3 4 5

1
-10

OUTPUT:
6

-1

5

-100000

8

0

15

-10
*/
