#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

class Solution {
public:
    void cal(int i, string& s, string temp, vector<string>& ans, unordered_map<string, bool>& m) {
        if (i == s.size()) {
            ans.push_back(temp);
            return;
        }
        string a = "";
        for (int j = i; j < s.size(); j++) {
            a += s[j];
            if (m[a]) {
                string newtemp = temp.empty() ? a : temp + " " + a;
                cal(j + 1, s, newtemp, ans, m);
            }
        }
    }

    vector<string> wordBreak(string s, vector<string>& wordDict) {
        unordered_map<string, bool> m;
        for (auto& val : wordDict) {
            m[val] = true;
        }
        vector<string> ans;
        cal(0, s, "", ans, m);
        return ans;
    }
};

int main() {
    Solution solution;
    string s;
    cin >> s;
    int n;
    cin >> n;
    vector<string> wordDict(n);
    for (int i = 0; i < n; i++) {
        cin >> wordDict[i];
    }

    vector<string> result = solution.wordBreak(s, wordDict);
    for (auto& sentence : result) {
        cout << sentence << endl;
    }
    return 0;
}
