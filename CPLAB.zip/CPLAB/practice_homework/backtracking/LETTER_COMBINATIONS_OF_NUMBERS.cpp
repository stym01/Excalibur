#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

class Solution {
public:
   void cal(int index, string& digits, vector<string>& v, string output, unordered_map<char, string>& m) {
       if(index >= digits.size()) {
           v.push_back(output);
           return;
       }
       for(int i = 0; i < m[digits[index]].length(); i++) {
           output.push_back(m[digits[index]][i]);
           cal(index + 1, digits, v, output, m);
           output.pop_back();
       }
   }

   vector<string> letterCombinations(string digits) {
       vector<string> v;
       if(digits.size() == 0) {
           return v;
       }
       unordered_map<char, string> m;
       m['2'] = "abc";
       m['3'] = "def";
       m['4'] = "ghi";
       m['5'] = "jkl";
       m['6'] = "mno";
       m['7'] = "pqrs";
       m['8'] = "tuv";
       m['9'] = "wxyz";
       string res = "";

       cal(0, digits, v, "", m);
       return v;
   }
};

int main() {
    Solution solution;
    string digits;
    cin >> digits;
    vector<string> result = solution.letterCombinations(digits);
    for(const string& s : result) {
        cout << s << " ";
    }
    cout << endl;
    return 0;
}
