#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Solution {
public:
    void cal(int index, vector<int>& candidates, vector<int> temp, vector<vector<int>>& v, int target) {
        if (target == 0) {
            v.push_back(temp);
            return;
        }
        for (int i = index; i < candidates.size(); i++) {
            if (i > index && candidates[i] == candidates[i - 1]) continue;
            if (candidates[i] > target) break;
            temp.push_back(candidates[i]);
            cal(i + 1, candidates, temp, v, target - candidates[i]);
            temp.pop_back();
        }
    }

    vector<vector<int>> combinationSum2(vector<int>& candidates, int target) {
        sort(candidates.begin(), candidates.end());
        vector<vector<int>> v;
        cal(0, candidates, {}, v, target);
        return v;
    }
};

int main() {
    Solution solution;
    int n, target;
    cin >> n;
    vector<int> candidates(n);
    for (int i = 0; i < n; i++) {
        cin >> candidates[i];
    }
    cin >> target;
    vector<vector<int>> result = solution.combinationSum2(candidates, target);
    for (auto& vec : result) {
        for (auto& num : vec) {
            cout << num << " ";
        }
        cout << endl;
    }
    return 0;
}
