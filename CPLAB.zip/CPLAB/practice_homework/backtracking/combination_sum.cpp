#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    void cal(int index, int target, vector<int> temp, vector<vector<int>>& v, vector<int>& candidates) {
        if (target == 0) {
            v.push_back(temp);
            return;
        }
        if (index >= candidates.size() || target < 0) {
            return;
        }

        cal(index + 1, target, temp, v, candidates);
        temp.push_back(candidates[index]);
        cal(index, target - candidates[index], temp, v, candidates);
    }

    vector<vector<int>> combinationSum(vector<int>& candidates, int target) {
        vector<vector<int>> v;
        cal(0, target, {}, v, candidates);
        return v;
    }
};

int main() {
    Solution solution;
    int n, target;
    cin >> n;
    vector<int> candidates(n);
    for (int i = 0; i < n; i++) {
        cin >> candidates[i];
    }
    cin >> target;
    vector<vector<int>> result = solution.combinationSum(candidates, target);
    for (auto& vec : result) {
        for (auto& num : vec) {
            cout << num << " ";
        }
        cout << endl;
    }
    return 0;
}
