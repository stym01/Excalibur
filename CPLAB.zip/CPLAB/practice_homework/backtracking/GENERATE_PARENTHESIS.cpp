#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    void cal(string op, int open, int close, vector<string>& v) {
        if (open == 0 && close == 0) {
            v.push_back(op);
            return;
        }

        if (open > 0) {
            cal(op + '(', open - 1, close, v);
        }

        if (close > open) {
            cal(op + ')', open, close - 1, v);
        }
    }

    vector<string> generateParenthesis(int n) {
        vector<string> v;
        cal("(", n - 1, n, v);
        return v;
    }
};

int main() {
    Solution solution;
    int n;
    cin >> n;
    vector<string> result = solution.generateParenthesis(n);
    for(const string& s : result) {
        cout << s << " ";
    }
    cout << endl;
    return 0;
}
