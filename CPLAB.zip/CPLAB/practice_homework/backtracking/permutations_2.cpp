#include <iostream>
#include <vector>
#include <set>
using namespace std;

class Solution {
public:
    void cal(vector<int> ds, set<vector<int>>& ans, int freq[], vector<int>& nums) {
        if (ds.size() == nums.size()) {
            ans.insert(ds);
            return;
        }
        for (int i = 0; i < nums.size(); i++) {
            if (!freq[i]) {
                freq[i] = 1;
                ds.push_back(nums[i]);
                cal(ds, ans, freq, nums);
                freq[i] = 0;
                ds.pop_back();
            }
        }
    }

    vector<vector<int>> permuteUnique(vector<int>& nums) {
        set<vector<int>> ans;
        vector<vector<int>> ans2;
        int freq[nums.size()];
        for (int i = 0; i < nums.size(); i++) {
            freq[i] = 0;
        }
        cal({}, ans, freq, nums);
        for (auto val : ans) {
            ans2.push_back(val);
        }
        return ans2;
    }
};

int main() {
    Solution solution;
    int n;
    cin >> n;
    vector<int> nums(n);
    for (int i = 0; i < n; i++) {
        cin >> nums[i];
    }

    vector<vector<int>> result = solution.permuteUnique(nums);
    for (auto& perm : result) {
        for (auto& num : perm) {
            cout << num << " ";
        }
        cout << endl;
    }
    return 0;
}
