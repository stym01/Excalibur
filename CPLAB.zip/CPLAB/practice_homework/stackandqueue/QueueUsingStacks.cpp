#include <iostream>
#include <stack>
using namespace std;
struct Queue_Stacks 
{
    stack<int> s1, s2;
public:
    void enqueue(int x) 
    {
        s1.push(x);
    }
    int dequeue() 
    {
        if (s2.empty()) 
        {
            if (s1.empty()) 
            {
                cout << "Queue is empty\n";
                return -1;
            }
            while (!s1.empty()) 
            {
                s2.push(s1.top());
                s1.pop();
            }
        }
        int front = s2.top();
        s2.pop();
        return front;
    }
    int front() 
    {
        if (s2.empty()) 
        {
            if (s1.empty()) 
            {
                cout << "Queue is empty\n";
                return -1;
            }
            while (!s1.empty()) 
            {
                s2.push(s1.top());
                s1.pop();
            }
        }
        return s2.top();
    }
    bool isEmpty() {
        return s1.empty() && s2.empty();
    }
};
int main() 
{
    Queue_Stacks q;
    q.enqueue(1);
    q.enqueue(2);
    q.enqueue(3);
    cout << "Dequeue: " << q.dequeue() << endl; 
    cout << "Front: " << q.front() << endl;     
    cout << "Dequeue: " << q.dequeue() << endl; 
    cout << "Dequeue: " << q.dequeue() << endl; 
    cout << "Dequeue: " << q.dequeue() << endl; 
    return 0;
}
