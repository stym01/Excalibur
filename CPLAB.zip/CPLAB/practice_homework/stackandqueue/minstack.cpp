#include <iostream>
#include <stack>
using namespace std;

class MinStack {
public:
    stack<pair<int,int>> s;

    MinStack() {}

    void push(int val) {
        if (s.empty()) 
            s.push({val, val});
        else if (s.top().second > val)
            s.push({val, val});
        else
            s.push({val, s.top().second});
    }

    void pop() {
        if (!s.empty())
            s.pop();
    }

    int top() {
        if (!s.empty())
            return s.top().first;
        return -1;
    }

    int getMin() {
        if (!s.empty())
            return s.top().second;
        return -1;
    }
};

int main() {
    MinStack* obj = new MinStack();
    int q;
    cin >> q;
    while (q--) {
        int type;
        cin >> type;
        if (type == 1) {
            int val;
            cin >> val;
            obj->push(val);
        } else if (type == 2) {
            obj->pop();
        } else if (type == 3) {
            cout << obj->top() << endl;
        } else if (type == 4) {
            cout << obj->getMin() << endl;
        }
    }
    delete obj;
    return 0;
}
