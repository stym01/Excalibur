#include <iostream>
#include <vector>
#include <stack>
#include <unordered_map>
using namespace std;

class Solution {
public:
    vector<int> nextGreaterElement(vector<int>& nums1, vector<int>& nums2) {
        int n = nums2.size();
        vector<int> ans(nums1.size());
        stack<int> st;
        unordered_map<int, int> m;
        
        for (int i = n - 1; i >= 0; i--) {
            while (!st.empty() && st.top() <= nums2[i]) {
                st.pop();
            }
            if (st.empty()) {
                m[nums2[i]] = -1;
            } else {
                m[nums2[i]] = st.top();
            }
            st.push(nums2[i]);
        }
        
        for (int i = 0; i < nums1.size(); i++) {
            ans[i] = m[nums1[i]];
        }
        
        return ans;
    }
};

int main() {
    int n, m;
    cin >> n;
    vector<int> nums1(n);
    for (int i = 0; i < n; i++) {
        cin >> nums1[i];
    }

    cin >> m;
    vector<int> nums2(m);
    for (int i = 0; i < m; i++) {
        cin >> nums2[i];
    }

    Solution obj;
    vector<int> result = obj.nextGreaterElement(nums1, nums2);

    for (int x : result) {
        cout << x << " ";
    }
    cout << endl;

    return 0;
}
