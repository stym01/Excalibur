#include <iostream>
#include <vector>
#include <queue>
using namespace std;

class Solution {
public:
    vector<int> maxSlidingWindow(vector<int>& nums, int k) {
        vector<int> ans;
        priority_queue<pair<int, int>> q;
        int i = 0, j = 0;

        while (j < nums.size()) {
            q.push({nums[j], j});

            if (j - i + 1 == k) {
                while (q.top().second < i) {
                    q.pop();
                }
                ans.push_back(q.top().first);
                i++;
            }
            j++;
        }

        return ans;
    }
};

int main() {
    int n, k;
    cin >> n;
    vector<int> nums(n);
    for (int i = 0; i < n; i++) {
        cin >> nums[i];
    }
    cin >> k;

    Solution obj;
    vector<int> result = obj.maxSlidingWindow(nums, k);

    for (int x : result) {
        cout << x << " ";
    }
    cout << endl;

    return 0;
}
