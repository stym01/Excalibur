#include <iostream>
using namespace std;

class node {
public:
    int val;
    node* next;
    node* prev;

    node(int val) {
        this->val = val;
        this->next = nullptr;
        this->prev = nullptr;
    }
};

class MyCircularDeque {
private:
    int k;
    int size;
    node* front;
    node* back;

public:
    MyCircularDeque(int k) {
        this->k = k;
        this->size = 0;
        this->front = nullptr;
        this->back = nullptr;
    }

    bool insertFront(int value) {
        if (size >= k) return false;
        node* newNode = new node(value);
        if (size == 0) {
            front = newNode;
            back = newNode;
        } else {
            newNode->next = front;
            front->prev = newNode;
            front = newNode;
        }
        size++;
        return true;
    }

    bool insertLast(int value) {
        if (size >= k) return false;
        node* newNode = new node(value);
        if (size == 0) {
            front = newNode;
            back = newNode;
        } else {
            back->next = newNode;
            newNode->prev = back;
            back = newNode;
        }
        size++;
        return true;
    }

    bool deleteFront() {
        if (size == 0) return false;
        node* temp = front;
        if (size == 1) {
            front = nullptr;
            back = nullptr;
        } else {
            front = front->next;
            front->prev = nullptr;
        }
        delete temp;
        size--;
        return true;
    }

    bool deleteLast() {
        if (size == 0) return false;
        node* temp = back;
        if (size == 1) {
            front = nullptr;
            back = nullptr;
        } else {
            back = back->prev;
            back->next = nullptr;
        }
        delete temp;
        size--;
        return true;
    }

    int getFront() {
        if (size == 0) return -1;
        return front->val;
    }

    int getRear() {
        if (size == 0) return -1;
        return back->val;
    }

    bool isEmpty() {
        return size == 0;
    }

    bool isFull() {
        return size == k;
    }
};

int main() {
    int capacity;
    cin >> capacity;
    MyCircularDeque deque(capacity);

    int q;
    cin >> q;
    while (q--) {
        int type;
        cin >> type;
        if (type == 1) {
            int val;
            cin >> val;
            cout << (deque.insertFront(val) ? "true" : "false") << endl;
        } else if (type == 2) {
            int val;
            cin >> val;
            cout << (deque.insertLast(val) ? "true" : "false") << endl;
        } else if (type == 3) {
            cout << (deque.deleteFront() ? "true" : "false") << endl;
        } else if (type == 4) {
            cout << (deque.deleteLast() ? "true" : "false") << endl;
        } else if (type == 5) {
            cout << deque.getFront() << endl;
        } else if (type == 6) {
            cout << deque.getRear() << endl;
        } else if (type == 7) {
            cout << (deque.isEmpty() ? "true" : "false") << endl;
        } else if (type == 8) {
            cout << (deque.isFull() ? "true" : "false") << endl;
        }
    }

    return 0;
}
