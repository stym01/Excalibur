#include <iostream>
#include <vector>
#include <stack>
using namespace std;

class Solution {
public:
    vector<int> asteroidCollision(vector<int>& asteroids) {
        stack<int> s;

        for (int i = 0; i < asteroids.size(); i++) {
            bool exploded = false;

            while (!s.empty() && s.top() > 0 && asteroids[i] < 0) {
                int top = s.top();
                if (abs(top) < abs(asteroids[i])) {
                    s.pop();
                } else if (abs(top) == abs(asteroids[i])) {
                    s.pop();
                    exploded = true;
                    break;
                } else {
                    exploded = true;
                    break;
                }
            }

            if (!exploded) {
                s.push(asteroids[i]);
            }
        }

        vector<int> result(s.size());
        for (int i = s.size() - 1; i >= 0; i--) {
            result[i] = s.top();
            s.pop();
        }

        return result;
    }
};

int main() {
    int n;
    cin >> n;
    vector<int> asteroids(n);
    for (int i = 0; i < n; i++) {
        cin >> asteroids[i];
    }

    Solution obj;
    vector<int> result = obj.asteroidCollision(asteroids);

    for (int x : result) {
        cout << x << " ";
    }
    cout << endl;

    return 0;
}
