#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    vector<int> Merge(vector<int>& nums1, vector<int>& nums2) {
        vector<int> temp;
        int i = 0;
        int j = 0;
        while (i < nums1.size() && j < nums2.size()) {
            if (nums1[i] <= nums2[j]) {
                temp.push_back(nums1[i]);
                i++;
            } else {
                temp.push_back(nums2[j]); 
                j++;
            }
        }
        while (i < nums1.size()) {
            temp.push_back(nums1[i]);
            i++;
        }
        while (j < nums2.size()) {
            temp.push_back(nums2[j]);
            j++;
        }
        return temp;
    }

    double findMedianSortedArrays(vector<int>& nums1, vector<int>& nums2) {
        vector<int> temp = Merge(nums1, nums2);
        int low = 0;
        int high = temp.size() - 1;
        if (temp.size() % 2 == 0) {
            int mid = (low + high) / 2;
            return (double)(temp[mid] + temp[mid + 1]) / 2;
        }
        return (double)temp[(low + high) / 2];
    }
};

int main() {
    Solution obj;
    
    vector<int> nums1 = {1, 3};
    vector<int> nums2 = {2};
    
    double median = obj.findMedianSortedArrays(nums1, nums2);
    
    cout << "The median of the two sorted arrays is: " << median << endl;
    
    return 0;
}
