#include <iostream>
#include <vector>
#include <queue>
using namespace std;

struct ListNode {
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};

class Solution {
public:
    ListNode* mergeKLists(vector<ListNode*>& lists) {
        priority_queue<pair<int, ListNode*>, vector<pair<int, ListNode*>>, greater<pair<int, ListNode*>>> q;
        
        for (int i = 0; i < lists.size(); i++) {
            if (lists[i]) {
                q.push({lists[i]->val, lists[i]});
            }
        }

        ListNode* prev = nullptr;
        ListNode* head = nullptr;

        while (!q.empty()) {
            auto val = q.top();
            q.pop();

            if (!head) {
                head = val.second;
                prev = head;
            } else {
                prev->next = val.second;
                prev = val.second;
            }

            if (val.second->next) {
                q.push({val.second->next->val, val.second->next});
            }
        }

        return head;
    }
};

int main() {
    Solution obj;
    
    vector<ListNode*> lists;
    
    ListNode* l1 = new ListNode(1, new ListNode(4, new ListNode(5)));
    ListNode* l2 = new ListNode(1, new ListNode(3, new ListNode(4)));
    ListNode* l3 = new ListNode(2, new ListNode(6));
    
    lists.push_back(l1);
    lists.push_back(l2);
    lists.push_back(l3);

    ListNode* mergedList = obj.mergeKLists(lists);

    while (mergedList) {
        cout << mergedList->val << " ";
        mergedList = mergedList->next;
    }
    cout << endl;

    return 0;
}
