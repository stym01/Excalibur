#include<bits/stdc++.h>
using namespace std;
 int countFreq(vector<int>& arr, int target) {
       int n=arr.size();
       int low=0;
       int high=n-1;
       int loweridx=-1;
       int upperidx=-1;
       while(low<=high){
        int mid=low+(high-low)/2;
        if(arr[mid]==target){
            loweridx=mid;
            if(mid>0 || arr[mid-1]!=target) high=mid-1;
        }
        else if(arr[mid]>target){
            high=mid-1;
        }
        else{
            low=mid+1;
        }
       }
       low=0;
       high=n-1;
       while(low<=high){
        int mid=low+(high-low)/2;
        if(arr[mid]==target){
            upperidx=mid;
            if(mid<n-1 || arr[mid+1]!=target) low=mid+1;
        }
        else if(arr[mid]>target){
            high=mid-1;
        }
        else{
            low=mid+1;
        }

       }
         if(loweridx==-1 && upperidx==-1) return 0;
        return upperidx-loweridx+1;
        
    }
int main(){
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        vector<int> arr(n);
        for(int i=0;i<n;i++){
            cin>>arr[i];
        }
        int x;
        cin>>x;
       
        cout<<countFreq(arr,x)<<endl;
    }
    return 0;
}
