#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

class Solution {
public:
    int findDuplicate(vector<int>& nums) {
        unordered_map<int, int> m;
        for (auto& val : nums) {
            m[val]++;
            if (m[val] > 1) return val;
        }
        
        return -1;
    }
};

int main() {
    Solution obj;
    int n;
    cin >> n;
    vector<int> nums(n);

   
    for (int i = 0; i < n; i++) {
        cin >> nums[i];
    }

   
    cout << obj.findDuplicate(nums) << endl;

    return 0;
}
