#include <bits/stdc++.h>

using namespace std;


void solveUsingHeap(vector<int>& arr,int k){
    int n=arr.size();
    priority_queue<int,vector<int>,greater<int>> q;
    for(int i=0;i<=k;i++){
        q.push(arr[i]);
    }
  int i=0;
  for(int j=k+1;j<n;j++){
    arr[i++]=q.top();
    q.pop();
    q.push(arr[j]);
  }
while(!q.empty()){
    arr[i++]=q.top();
    q.pop();
  }
   
  
       
        
    

    


}
  
int main(){
    int t;
    cin>>t;
    while(t--){
        int n,k;
        cin>> n>> k;
        vector<int> arr(n);
        for(int i=0;i<n;i++){
            cin>> arr[i];
        }
        solveUsingHeap(arr,k);
        for(int i=0;i<n;i++){
            cout<< arr[i]<<" ";
        }
    }

    return 0;
}