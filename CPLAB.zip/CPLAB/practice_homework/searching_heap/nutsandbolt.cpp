#include <bits/stdc++.h>
using namespace std;

int partition(int arr[], int low,  
            int high, int pivot) 
{ 
    int i = low-1; 
   
      
    for(int j = low; j < high; j++) 
    { 
        if (arr[j] < pivot) 
        { 
            i++;
           swap(arr[i],arr[j]);
           
        }  
        else if(arr[j] == pivot) 
        { 
           swap(arr[j],arr[high]);
           j--;
        } 
    }  
  swap(arr[i+1],arr[high]);
  
    
    return i+1; 
} 

void quicksort(int nuts[], int bolts[], int low, int high) {
    if (low >= high) return;

    int pivot = bolts[high];  
    int pi = partition(nuts, low, high, pivot);

    partition(bolts, low, high, nuts[pi]);  

    quicksort(nuts, bolts, low, pi - 1);
    quicksort(nuts, bolts, pi + 1, high);
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        int nuts[n], bolts[n];

        for (int i = 0; i < n; i++) cin >> nuts[i];
        for (int i = 0; i < n; i++) cin >> bolts[i];

        quicksort(nuts, bolts, 0, n - 1);

        for (int i = 0; i < n; i++) cout << nuts[i] << " ";
        cout << endl;
        for (int i = 0; i < n; i++) cout << bolts[i] << " ";
        cout << endl;
    }
    return 0;
}
