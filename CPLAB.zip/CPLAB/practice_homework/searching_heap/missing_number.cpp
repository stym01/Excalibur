#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    int missingNumber(vector<int>& nums) {
        int n = nums.size();
        
        
        // int sum = (n * (n + 1)) / 2, sum2 = 0;
        // for (int i = 0; i < nums.size(); i++) {
        //     sum2 = sum2 + nums[i];
        // }
        // return (sum - sum2);

        // XOR method
        int x = 0;
        for (int i = 0; i <= n; i++) x = x ^ i;
        for (int i = 0; i < n; i++)  x = nums[i] ^ x;
        return x;
    }
};

int main() {
    Solution obj;
    int n;
    cin >> n;
    vector<int> nums(n);

    
    for (int i = 0; i < n; i++) {
        cin >> nums[i];
    }

   
    cout << obj.missingNumber(nums) << endl;

    return 0;
}
