#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Solution {
public:
    int eraseOverlapIntervals(vector<vector<int>>& intervals) {
        int n = intervals.size();
        if (n == 0) return 0;
        
        sort(intervals.begin(), intervals.end(), [](const vector<int>& a, const vector<int>& b) {
            return a[1] < b[1];
        });
        
        int ans = 0;
        int prevEnd = intervals[0][1];
        
        for (int i = 1; i < n; i++) {
            if (intervals[i][0] < prevEnd) {
                ans += 1;
            } else {
                prevEnd = intervals[i][1];
            }
        }
        
        return ans;
    }
};

int main() {
    Solution solution;
    int n;
    cout << "Enter number of intervals: ";
    cin >> n;
    vector<vector<int>> intervals(n, vector<int>(2));
    
    cout << "Enter intervals (start and end):" << endl;
    for (int i = 0; i < n; i++) {
        cin >> intervals[i][0] >> intervals[i][1];
    }
    
    int result = solution.eraseOverlapIntervals(intervals);
    cout << "Minimum number of intervals to remove: " << result << endl;
    
    return 0;
}
