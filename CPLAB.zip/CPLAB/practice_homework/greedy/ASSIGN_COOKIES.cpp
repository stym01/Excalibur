#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Solution {
public:
    int findContentChildren(vector<int>& g, vector<int>& s) {
        sort(g.begin(), g.end());
        sort(s.begin(), s.end());
        int l = 0, r = 0, count = 0;

        while (l < g.size() && r < s.size()) {
            if (g[l] <= s[r]) {
                count++;
                l++;
                r++;
            } else {
                r++;
            }
        }
        return count;
    }
};

int main() {
    Solution solution;
    int n, m;
    cout << "Enter number of children: ";
    cin >> n;
    vector<int> g(n);
    cout << "Enter greed factors of children: ";
    for (int i = 0; i < n; i++) {
        cin >> g[i];
    }

    cout << "Enter number of cookies: ";
    cin >> m;
    vector<int> s(m);
    cout << "Enter sizes of cookies: ";
    for (int i = 0; i < m; i++) {
        cin >> s[i];
    }

    int result = solution.findContentChildren(g, s);
    cout << "Maximum number of content children: " << result << endl;

    return 0;
}
