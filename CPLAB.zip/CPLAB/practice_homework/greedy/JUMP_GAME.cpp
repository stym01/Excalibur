#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Solution {
public:
    // bool cal(int index,vector<int>& nums,vector<int>& dp){
    //     if (index == nums.size() - 1) {
    //         return true;
    //     }
    //     if (index >= nums.size() || nums[index] == 0) {
    //         return false;
    //     }
    //     if (dp[index] != -1) {
    //         return dp[index];
    //     }
        
    //     for (int i = 1; i <= nums[index]; i++) {
    //         if (cal(index + i, nums, dp)) {
    //             return dp[index] = true;
    //         }
    //     }
        
    //     return dp[index] = false;
    // }
    bool canJump(vector<int>& nums) {
        // vector<int> dp(nums.size(),-1);
        // return cal(0,nums,dp);
        int maxindex=0;
        for(int i=0;i<nums.size();i++){
            if(i>maxindex) return false;
            maxindex=max(maxindex,i+nums[i]);
        }
        return true;
    }
};

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    Solution solution;
    int n;
    cin >> n;
    vector<int> nums(n);
    for(int i = 0; i < n; i++) {
        cin >> nums[i];
    }
    cout << (solution.canJump(nums) ? "true" : "false") << endl;
    return 0;
}
