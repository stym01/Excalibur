#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Solution {
public:
    int findPlatform(vector<int>& arr, vector<int>& dep) {
        sort(arr.begin(), arr.end());
        sort(dep.begin(), dep.end());
        int n = arr.size();
        int platforms = 1;
        int result = 1;
        int i = 1, j = 0;
        while (i < n && j < n) {
            if (arr[i] <= dep[j]) {
                platforms++;
                i++;
            } else {
                platforms--;
                j++;
            }
            result = max(result, platforms);
        }
        return result;
    }
};

int main() {
    Solution solution;
    int n;
    cout << "Enter the number of trains: ";
    cin >> n;
    vector<int> arr(n), dep(n);
    cout << "Enter the arrival times: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
    cout << "Enter the departure times: ";
    for (int i = 0; i < n; i++) {
        cin >> dep[i];
    }
    cout << "Minimum number of platforms required: " << solution.findPlatform(arr, dep) << endl;
    return 0;
}
