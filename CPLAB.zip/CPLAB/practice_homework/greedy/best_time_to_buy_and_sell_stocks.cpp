#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Solution {
public:
    int maxProfit(vector<int>& prices) {
        int i = prices[0];
        int j;
        int profit = 0;
        int k;
        int n = prices.size();
        for (j = 1; j < n; j++) {
            k = prices[j] - i;
            if (k < 0) {
                i = prices[j];
            } else {
                profit = max(profit, k);
            }
        }
        return profit;
    }
};

int main() {
    Solution solution;
    int n;
    cout << "Enter the number of days: ";
    cin >> n;
    vector<int> prices(n);
    cout << "Enter the prices for each day: ";
    for (int i = 0; i < n; i++) {
        cin >> prices[i];
    }
    cout << "Maximum profit: " << solution.maxProfit(prices) << endl;
    return 0;
}
