#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    int canCompleteCircuit(vector<int>& gas, vector<int>& cost) {
        int sum1 = 0, sum2 = 0;
        int curr = 0, ans = 0;
        for (int i = 0; i < gas.size(); i++) {
            sum1 += gas[i];
            sum2 += cost[i];
            curr += gas[i] - cost[i];
            if (curr < 0) {
                curr = 0;
                ans = i + 1;
            }
        }
        return sum1 < sum2 ? -1 : ans;
    }
};

int main() {
    Solution solution;
    int n;
    cout << "Enter number of gas stations: ";
    cin >> n;
    vector<int> gas(n), cost(n);
    
    cout << "Enter gas at each station: ";
    for (int i = 0; i < n; i++) {
        cin >> gas[i];
    }
    
    cout << "Enter cost to reach next station: ";
    for (int i = 0; i < n; i++) {
        cin >> cost[i];
    }
    
    int result = solution.canCompleteCircuit(gas, cost);
    cout << "Starting station index: " << result << endl;
    
    return 0;
}
