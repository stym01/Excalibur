#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Solution {
public:
    int maxArea(vector<int>& nums) {
        int n = nums.size();
        int i = 0, j = n - 1;
        int ans = 0;
        while (i < j) {
            ans = max(ans, (j - i) * min(nums[i], nums[j]));
            if (nums[i] > nums[j]) j--;
            else i++;
        }
        return ans;
    }
};

int main() {
    Solution solution;
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;
    vector<int> nums(n);
    cout << "Enter the elements: ";
    for (int i = 0; i < n; i++) {
        cin >> nums[i];
    }
    cout << "Maximum area: " << solution.maxArea(nums) << endl;
    return 0;
}
