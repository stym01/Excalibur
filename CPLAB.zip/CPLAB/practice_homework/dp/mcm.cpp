#include <iostream>
#include <vector>
#include <climits>
using namespace std;

int matrixChainMultiplication(const vector<int>& dims) {
    int n = dims.size() - 1;
    vector<vector<int>> dp(n, vector<int>(n, 0));

    for (int l = 2; l <= n; l++) {
        for (int i = 0; i <= n - l; i++) {
            int j = i + l - 1;
            dp[i][j] = INT_MAX;
            for (int k = i; k < j; k++) {
                int cost = dp[i][k] + dp[k+1][j] + dims[i] * dims[k+1] * dims[j+1];
                if (cost < dp[i][j]) {
                    dp[i][j] = cost;
                }
            }
        }
    }
    return dp[0][n-1];
}

int main() {
    int n;
    cin >> n;

    vector<int> dims(n + 1);
    for (int i = 0; i <= n; i++) {
        cin >> dims[i];
    }

    cout << matrixChainMultiplication(dims) << endl;

    return 0;
}
