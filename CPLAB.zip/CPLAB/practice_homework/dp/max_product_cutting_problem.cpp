#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    // vector<int> dp;

    // int cal(int n) {
    //     if (n == 1) return 1;
    //     if (dp[n] != -1) return dp[n];

    //     int ans = 0;
    //     for (int i = 1; i < n; i++) {
           
    //         int option1 = i * (n - i);       
    //         int option2 = i * cal(n - i);    
    //         ans = max({ans, option1, option2});
    //     }

    //     return dp[n] = ans;
    // }

    int integerBreak(int n) {
        // dp.resize(n + 1, -1);
        // return cal(n);
        vector<int> dp(n+1);
        dp[1]=1;
        for(int i=2;i<=n;i++){
            int ans=0;
            for(int j=1;j<i;j++){
                int op1=j*(i-j);
                int op2=j*dp[i-j];
                ans=max(ans,op1);
                ans=max(ans,op2);
            }
            dp[i]=ans;
        }
        return dp[n];
    }
};

int main() {
    int n;
    cin >> n;
    
    Solution sol;
    cout << sol.integerBreak(n) << endl;
    
    return 0;
}
