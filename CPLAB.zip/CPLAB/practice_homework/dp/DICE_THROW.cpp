#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    // int cal(int n,int k,int target,int MOD, vector<vector<int>>& dp){
    //      if(n==0) return target==0;
    //     if(target<0) return 0;
       
    //     if(dp[n][target]!=-1) return dp[n][target];
    //     int ans=0;
    //     for(int i=1;i<=k;i++){
           
    //        if(target-i>=0){
    //         ans=(ans+cal(n-1,k,target-i,MOD,dp))%MOD;
    //        }
           
    //     }
    //        return dp[n][target]=ans;
    // }
    int numRollsToTarget(int n, int k, int target) {
        int MOD=1e9+7;
        vector<vector<int>> dp(n+1,vector<int>(target+1,0));
        
        // return cal(n,k,target,MOD,dp);
        dp[0][0]=1;
        for(int i=1;i<=n;i++){
            for(int sum=1;sum<=target;sum++){
                int ans=0;
                for(int j=1;j<=k;j++){
                    if(sum-j>=0){
                        ans =(ans+dp[i-1][sum-j])%MOD;
                    }
                }
                dp[i][sum]=ans;
            }
        }
          return dp[n][target];         
    }
};

int main() {
    int n, k, target;
    cin >> n >> k >> target;

    Solution sol;
    cout << sol.numRollsToTarget(n, k, target) << endl;

    return 0;
}
