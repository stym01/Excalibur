#include <iostream>
#include <vector>
#include <climits>
using namespace std;

class Solution {
public:
    // int cal(int k, int n, vector<vector<int>>& dp){
    //     if(n == 0 || n == 1) return n;
    //     if(k == 1) return n;
    //     
    //     if(dp[k][n] != -1) return dp[k][n];
    //     
    //     int mn = INT_MAX, low = 0, high = n, temp = 0;
    //     
    //     while(low<=high){
    //         int mid = (low + high)/2;
    //         int left = cal(k-1, mid-1, dp);
    //         int right = cal(k, n-mid, dp);
    //         
    //         temp = 1 + max(left, right);
    //         
    //         if(left < right) 
    //             low = mid+1;
    //         else 
    //             high = mid-1;    
    //         
    //         mn = min(mn, temp);
    //     }
    //     return dp[k][n] = mn;
    // }
    
    int superEggDrop(int k, int n) {
       
        vector<vector<int>> dp(k+1, vector<int>(n+1, 0));
        
     
        for(int i = 0; i <= k; i++) {
            dp[i][0] = 0;  
            dp[i][1] = 1;  
        }
        
        for(int j = 0; j <= n; j++) {
            dp[1][j] = j;  
        }
        
        
        for(int i = 2; i <= k; i++) {
            for(int j = 2; j <= n; j++) {
                int low = 1, high = j;
                int mn = INT_MAX;
                
               
                while(low <= high) {
                    int mid = (low + high) / 2;
                    int left = dp[i-1][mid-1]; 
                    int right = dp[i][j-mid];   
                    
                    int temp = 1 + max(left, right);
                    mn = min(mn, temp);
                    
                    if(left < right) 
                        low = mid + 1;
                    else 
                        high = mid - 1;
                }
                
                dp[i][j] = mn;
            }
        }
        
        return dp[k][n];
    }
};

int main() {
    int k, n;
    cin >> k >> n;
    
    Solution sol;
    cout << sol.superEggDrop(k, n) << endl;
    
    return 0;
}
