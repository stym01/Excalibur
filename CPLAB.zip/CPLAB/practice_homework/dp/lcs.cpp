#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Solution {
public:
    // int cal(int i,int prev,vector<int>& nums,vector<vector<int>>& dp){
    //     if(i==-1) return 0;
    //     if(dp[i][prev]!=-1) return dp[i][prev];
    //     int take=0,ntake=0;
    //     if(prev==nums.size() || nums[i]<nums[prev]){
    //         take=1+cal(i-1,i,nums,dp);

    //     } 
    //     ntake=cal(i-1,prev,nums,dp);
    //     return dp[i][prev]=max(take,ntake);
    // }
    int lengthOfLIS(vector<int>& nums) {
    //    vector<int> dp(nums.size(),1);
    //    int maxi=1;
    //    for(int i=1;i<nums.size();i++){
    //     for(int j=0;j<i;j++){
    //         if(nums[i]>nums[j]){
    //             dp[i]=max(dp[i],dp[j]+1);
    //         }
    //     }
    //     maxi=max(maxi,dp[i]);
    //    }
    //   return maxi; 
    vector<int> v;
    v.push_back(nums[0]);
    for(int i=1;i<nums.size();i++){
        if(nums[i]>v.back()){
            v.push_back(nums[i]);
        }
        else{
            int j=lower_bound(v.begin(),v.end(),nums[i])-v.begin();
            v[j]=nums[i];
        }
    } 
    return v.size();
    }
};

int main() {
    int n;
    cin >> n;
    vector<int> nums(n);
    for(int i = 0; i < n; i++) {
        cin >> nums[i];
    }

    Solution sol;
    cout << sol.lengthOfLIS(nums) << endl;

    return 0;
}
