#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Solution {
public:
    // int cal(int i,int sum,vector<int>& nums,vector<vector<int>>& dp){
    //    if(sum==0) return 0;
    //    if(i==-1) return 1e8;
    //    if(dp[i][sum]!=-1) return dp[i][sum];
    //    int take=1e8,ntake=0;
    //    if((sum-nums[i])>=0) take=1+cal(i,sum-nums[i],nums,dp);
    //    ntake=cal(i-1,sum,nums,dp);
    //    return  dp[i][sum]=  min(take,ntake);
    // }
    int coinChange(vector<int>& coins, int amount) {
        int n=coins.size();
        // if(amount==0) return 0;
        vector<int> dp(amount+1);
        // int x= cal(coins.size()-1,amount,coins,dp);
        // if(x==INT_MAX) return -1;
        // return x;
        // int x=cal(coins.size()-1,amount,coins,dp);
        // return (x==1e8 ? -1 : x);
        for(int sum=0;sum<=amount;sum++){
            if(sum%coins[0]==0) dp[sum]=sum/coins[0];
            else dp[sum]=1e9;
        }
        for(int i=1;i<n;i++){
            for(int sum=0;sum<=amount;sum++){
                int take=1e9,ntake=0;
                if(sum>=coins[i]) take=1+dp[sum-coins[i]];
                dp[sum]=min(take,dp[sum]);
            }
        }
        return dp[amount]==1e9 ? -1 : dp[amount];
    }
};

int main() {
    int n;
    cin >> n;
    vector<int> coins(n);
    for(int i = 0; i < n; i++) {
        cin >> coins[i];
    }
    int amount;
    cin >> amount;
    
    Solution sol;
    cout << sol.coinChange(coins, amount) << endl;
    
    return 0;
}
