#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    // bool cal(int i,int sum,vector<int>& nums,vector<vector<int>>& dp){
    //     if(sum==0) return true;
    //     if(i==nums.size()) return false;
    //     if(dp[i][sum]!=-1) return dp[i][sum];
    //     bool take=false,ntake;
    //     if(sum>=nums[i]) take=cal(i+1,sum-nums[i],nums,dp);
    //     ntake=cal(i+1,sum,nums,dp);
    //     return dp[i][sum]=     take || ntake;
    // }
    
    bool canPartition(vector<int>& nums) {
        int sum=0;
        for(auto& val:nums) sum+=val;
        if(sum & 1) return false;
        sum=sum/2;
        vector<vector<bool>> dp(nums.size()+1,vector<bool>(sum+1,false));
        // return cal(0,sum,nums,dp);
        int n=nums.size();
        for(int i=0;i<=n;i++) dp[i][0]=true;
        for(int i=n-1;i>=0;i--){
            for(int j=0;j<=sum;j++){
                bool take=false,ntake;
                if(j>=nums[i]) take=dp[i+1][j-nums[i]];
                ntake=dp[i+1][j];
                dp[i][j]=take || ntake;
            }
        }
        return dp[0][sum];
    }
};

int main() {
    int n;
    cin >> n;
    vector<int> nums(n);
    for(int i = 0; i < n; i++) {
        cin >> nums[i];
    }

    Solution sol;
    cout << sol.canPartition(nums) << endl;
    
    return 0;
}
