#include <iostream>
#include <vector>
#include <functional>  // Include the functional header

using namespace std;

struct ListNode {
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};

class Solution {
public:
    TreeNode* cal(vector<int>& v, int st, int ed) {
        if (st > ed) {
            return NULL;
        }
        int mid = st + (ed - st) / 2;
        TreeNode* root = new TreeNode(v[mid]);
        root->left = cal(v, st, mid - 1);
        root->right = cal(v, mid + 1, ed);
        return root;
    }

    TreeNode* sortedListToBST(ListNode* head) {
        if (head == NULL) {
            return NULL;
        }
        ListNode* last = head;
        vector<int> v;
        while (last) {
            v.push_back(last->val);
            last = last->next;
        }
        return cal(v, 0, v.size() - 1);
    }
};

int main() {
    ListNode* head = new ListNode(1);
    head->next = new ListNode(2);
    head->next->next = new ListNode(3);
    head->next->next->next = new ListNode(4);
    head->next->next->next->next = new ListNode(5);

    Solution sol;
    TreeNode* root = sol.sortedListToBST(head);

    function<void(TreeNode*)> inorder = [&](TreeNode* node) {
        if (node) {
            inorder(node->left);
            cout << node->val << " ";
            inorder(node->right);
        }
    };

    inorder(root);  

    return 0;
}
