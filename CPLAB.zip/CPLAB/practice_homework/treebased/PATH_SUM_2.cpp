#include <iostream>
#include <vector>

using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};

class Solution {
public:
    void cal(TreeNode* root, int target, vector<int> temp, vector<vector<int>>& v) {
        if (root == NULL) {
            return;
        }
        temp.push_back(root->val);

        if (root->left == NULL && root->right == NULL) {
            target -= root->val;
            if (target == 0) {
                v.push_back(temp);
            }
            return;
        }
        cal(root->left, target - root->val, temp, v);
        cal(root->right, target - root->val, temp, v);
    }

    vector<vector<int>> pathSum(TreeNode* root, int targetSum) {
        vector<vector<int>> v;
        cal(root, targetSum, {}, v);
        return v;
    }
};

int main() {
    TreeNode* root = new TreeNode(5);
    root->left = new TreeNode(4);
    root->right = new TreeNode(8);
    root->left->left = new TreeNode(11);
    root->left->left->left = new TreeNode(7);
    root->left->left->right = new TreeNode(2);
    root->right->left = new TreeNode(13);
    root->right->right = new TreeNode(4);
    root->right->right->right = new TreeNode(1);

    Solution sol;
    int targetSum = 22;
    vector<vector<int>> result = sol.pathSum(root, targetSum);

    for (const auto& path : result) {
        for (int val : path) {
            cout << val << " ";
        }
        cout << endl;
    }

    return 0;
}
