#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};

class Solution {
public:
    TreeNode* cal(vector<int>& inorder, int ins, int ine, vector<int>& postorder, int pos, int poe, unordered_map<int,int>& m) {
        if (ins > ine || pos > poe) {
            return NULL;
        }
        TreeNode* root = new TreeNode(postorder[poe]);
        int i = m[postorder[poe]];

        root->left = cal(inorder, ins, i - 1, postorder, pos, poe - ine + i - 1, m);
        root->right = cal(inorder, i + 1, ine, postorder, poe - ine + i, poe - 1, m);
        return root;
    }

    TreeNode* buildTree(vector<int>& inorder, vector<int>& postorder) {
        unordered_map<int, int> m;
        for (int i = 0; i < inorder.size(); i++) {
            m[inorder[i]] = i;
        }
        return cal(inorder, 0, inorder.size() - 1, postorder, 0, postorder.size() - 1, m);
    }
};

void preorderTraversal(TreeNode* root) {
    if (root != nullptr) {
        cout << root->val << " ";
        preorderTraversal(root->left);
        preorderTraversal(root->right);
    }
}

int main() {
    Solution solution;

    vector<int> inorder = {9, 3, 15, 20, 7};
    vector<int> postorder = {9, 15, 7, 20, 3};

    TreeNode* root = solution.buildTree(inorder, postorder);

    cout << "Preorder Traversal of the constructed tree: ";
    preorderTraversal(root);  // Output the preorder traversal of the reconstructed tree
    cout << endl;

    return 0;
}
