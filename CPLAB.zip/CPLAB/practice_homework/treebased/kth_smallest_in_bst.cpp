#include <iostream>

using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

class Solution {
public:
    void cal(TreeNode* root, int& k, int& ans) {
        if (!root) return;
        cal(root->left, k, ans);
        k--;
        if (k == 0) {
            ans = root->val;
            return;
        }
        cal(root->right, k, ans);
    }

    int kthSmallest(TreeNode* root, int k) {
        int ans;
        cal(root, k, ans);
        return ans;
    }
};

int main() {
    TreeNode* root = new TreeNode(5);
    root->left = new TreeNode(3);
    root->right = new TreeNode(6);
    root->left->left = new TreeNode(2);
    root->left->right = new TreeNode(4);
    root->left->left->left = new TreeNode(1);

    int k = 3;
    Solution sol;
    int result = sol.kthSmallest(root, k);
    
    cout << "The " << k << "rd smallest element is: " << result << endl;
    
    return 0;
}
