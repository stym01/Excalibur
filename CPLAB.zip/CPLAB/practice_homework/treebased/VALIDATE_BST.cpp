#include <iostream>
#include <climits>
using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};

class Solution {
public:
    bool check(TreeNode* root, long a, long b) {
        if (root == NULL) {
            return true;
        }
        if (root->val <= a || root->val >= b) {
            return false;
        }
        bool c1 = check(root->left, a, root->val);
        bool c2 = check(root->right, root->val, b);
        if (!c1 || !c2) {
            return false;
        }
        return true;
    }

    bool isValidBST(TreeNode* root) {
        return check(root, LONG_MIN, LONG_MAX);
    }
};

int main() {
    // Create a test tree
    TreeNode* root = new TreeNode(2);
    root->left = new TreeNode(1);
    root->right = new TreeNode(3);

    Solution solution;
    bool result = solution.isValidBST(root);
    cout << (result ? "True" : "False") << endl;

    return 0;
}
