#include <iostream>
#include <vector>
#include <queue>
using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode() : val(0), left(nullptr), right(nullptr) {}
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
    TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
};

class Solution {
public:
    int maxDepth(TreeNode* root) {
        if(root == nullptr) {
            return 0;
        }
        int leftDepth = 1 + maxDepth(root->left);
        int rightDepth = 1 + maxDepth(root->right);
        return max(leftDepth, rightDepth);
    }

    TreeNode* insertLevelOrder(vector<int>& arr, TreeNode* root, int i, int n) {
        if (i < n) {
            TreeNode* temp = new TreeNode(arr[i]);
            root = temp;
            root->left = insertLevelOrder(arr, root->left, 2 * i + 1, n);
            root->right = insertLevelOrder(arr, root->right, 2 * i + 2, n);
        }
        return root;
    }

    TreeNode* createTreeFromInput() {
        int n;
        cin >> n;
        if (n == 0) return nullptr;

        vector<int> nodes(n);
        for (int i = 0; i < n; ++i) {
            cin >> nodes[i];
        }

        return insertLevelOrder(nodes, nullptr, 0, n);
    }
};

int main() {
    Solution solution;
    TreeNode* root = solution.createTreeFromInput();
    int depth = solution.maxDepth(root);
    cout << depth << endl;
    return 0;
}
