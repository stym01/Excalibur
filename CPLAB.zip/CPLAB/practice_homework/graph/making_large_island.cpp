#include <iostream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
using namespace std;

class Solution {
public:
    int dfs(int i, int j, vector<vector<int>>& grid, vector<vector<int>>& componentGrid, 
            int compID, vector<pair<int, int>>& directions) {
        int n = grid.size();
        int size = 1;
        componentGrid[i][j] = compID;

        for (auto& d : directions) {
            int x = i + d.first, y = j + d.second;
            if (x >= 0 && y >= 0 && x < n && y < n && grid[x][y] == 1 && componentGrid[x][y] == -1) {
                size += dfs(x, y, grid, componentGrid, compID, directions);
            }
        }
        return size;
    }

    int largestIsland(vector<vector<int>>& grid) {
        int n = grid.size();
        vector<pair<int, int>> directions = {{0, 1}, {1, 0}, {-1, 0}, {0, -1}};
        vector<vector<int>> componentGrid(n, vector<int>(n, -1)); 
        unordered_map<int, int> componentSize; 
        int compID = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (grid[i][j] == 1 && componentGrid[i][j] == -1) {
                    componentSize[compID] = dfs(i, j, grid, componentGrid, compID, directions);
                    compID++;
                }
            }
        }

        int maxIsland = 0;
        for (auto& size : componentSize) {
            maxIsland = max(maxIsland, size.second); 
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (grid[i][j] == 0) {
                    unordered_set<int> seen;
                    int possibleSize = 1;

                    for (auto& d : directions) {
                        int x = i + d.first, y = j + d.second;
                        if (x >= 0 && y >= 0 && x < n && y < n && componentGrid[x][y] != -1) {
                            int id = componentGrid[x][y];
                            if (seen.find(id) == seen.end()) {
                                possibleSize += componentSize[id];
                                seen.insert(id);
                            }
                        }
                    }

                    maxIsland = max(maxIsland, possibleSize);
                }
            }
        }

        return maxIsland;
    }
};

int main() {
    int n;
    cin >> n;
    vector<vector<int>> grid(n, vector<int>(n));
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> grid[i][j];
        }
    }

    Solution solution;
    int result = solution.largestIsland(grid);
    cout << result << endl;

    return 0;
}
