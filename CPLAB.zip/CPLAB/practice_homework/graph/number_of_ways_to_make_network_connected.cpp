#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    class DSU {
        vector<int> size, parent;

    public:
        DSU(int n) {
            size.resize(n, 1);
            parent.resize(n);
            for (int i = 0; i < n; i++) {
                parent[i] = i;
            }
        }

        int findparent(int u) {
            if (parent[u] == u) return u;
            return parent[u] = findparent(parent[u]);
        }

        void unite(int u, int v) {
            int pu = findparent(u);
            int pv = findparent(v);
           
            if (size[pu] > size[pv]) {
                size[pu] += size[pv];
                parent[pv] = pu;
            } else {
                size[pv] += size[pu];
                parent[pu] = pv;
            }
        }
    };

    int makeConnected(int n, vector<vector<int>>& connections) {
        if (connections.size() < n - 1) return -1;
        DSU dsu(n);
          
        for (auto& val : connections) {
            int u = val[0];
            int v = val[1];
            if (dsu.findparent(u) != dsu.findparent(v)) {
                dsu.unite(u, v);
            }
        }
        int count = 0;
        for (int i = 0; i < n; i++) {
            if (dsu.findparent(i) == i) count++;
        }
        return count - 1;
    }
};

int main() {
    int n, m;
    cin >> n >> m;  // Read number of nodes and number of connections
    vector<vector<int>> connections(m, vector<int>(2));
    
    for (int i = 0; i < m; i++) {
        cin >> connections[i][0] >> connections[i][1];  // Read each connection
    }
    
    Solution solution;
    int result = solution.makeConnected(n, connections);
    cout << result << endl;  // Output the result
    return 0;
}
