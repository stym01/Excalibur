#include <iostream>
#include <vector>
#include <queue>
using namespace std;

class Solution {
public:
    bool isBipartite(vector<vector<int>>& graph) {
        int n = graph.size();
        vector<int> color(n, -1);

        for (int i = 0; i < n; i++) {
            if (color[i] == -1) {
                queue<int> q;
                q.push(i);
                color[i] = 0;

                while (!q.empty()) {
                    int x = q.front();
                    q.pop();
                    for (auto it : graph[x]) {
                        if (color[it] == -1) {  
                            color[it] = !color[x];
                            q.push(it);
                        } else if (color[it] == color[x]) {
                            return false;  
                        }
                    }
                }
            }
        }

        return true;
    }
};

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<int>> graph(n);

   
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }

    Solution solution;
    bool result = solution.isBipartite(graph);
    cout << (result ? "Yes" : "No") << endl;

    return 0;
}
