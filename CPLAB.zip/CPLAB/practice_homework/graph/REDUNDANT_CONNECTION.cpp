#include <iostream>
#include <vector>
using namespace std;

class Disjoint_set {
public:
    vector<int> parent, size;

    Disjoint_set(int n) {
        parent.resize(n + 1);
        size.resize(n + 1, 1);
        for (int i = 0; i <= n; i++) {
            parent[i] = i;
        }
    }

    int findParent(int val) {
        if (parent[val] == val) return val;
        return parent[val] = findParent(parent[val]); // Path compression
    }

    void unionSets(int u, int v) {
        int rootU = findParent(u);
        int rootV = findParent(v);

        if (rootU != rootV) {
            if (size[rootU] > size[rootV]) {
                parent[rootV] = rootU;
                size[rootU] += size[rootV];
            } else {
                parent[rootU] = rootV;
                size[rootV] += size[rootU];
            }
        }
    }
};

class Solution {
public:
    vector<int> findRedundantConnection(vector<vector<int>>& edges) {
        int n = edges.size(); 
        Disjoint_set s(n);  

        int ans = -1;
        for (int i = 0; i < n; i++) {
            int val1 = edges[i][0];
            int val2 = edges[i][1];

            if (s.findParent(val1) == s.findParent(val2)) {
                ans = i;
            } else {
                s.unionSets(val1, val2); 
            }
        }

        return {edges[ans][0], edges[ans][1]};
    }
};

int main() {
    int n, m;
    cin >> n >> m;  // Read the number of nodes and edges

    vector<vector<int>> edges(m, vector<int>(2));
    for (int i = 0; i < m; i++) {
        cin >> edges[i][0] >> edges[i][1];  // Read each edge
    }

    Solution solution;
    vector<int> redundantEdge = solution.findRedundantConnection(edges);
    cout << redundantEdge[0] << " " << redundantEdge[1] << endl;  // Output the redundant edge
    return 0;
}
