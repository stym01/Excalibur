#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;


class Node {
public:
    int val;
    vector<Node*> neighbors;
    Node() {
        val = 0;
        neighbors = vector<Node*>();
    }
    Node(int _val) {
        val = _val;
        neighbors = vector<Node*>();
    }
    Node(int _val, vector<Node*> _neighbors) {
        val = _val;
        neighbors = _neighbors;
    }
};


class Solution {
public:
    unordered_map<Node*, Node*> m;
    
    Node* cloneGraph(Node* node) {
        if (!node) return nullptr;
        if (m.find(node) != m.end()) return m[node];

        Node* newnode = new Node(node->val);
        m[node] = newnode;

        for (auto& val : node->neighbors) {
            newnode->neighbors.push_back(cloneGraph(val));
        }

        return newnode;
    }
};

Node* createGraph(int n) {
    unordered_map<int, Node*> nodeMap;
    for (int i = 1; i <= n; ++i) {
        nodeMap[i] = new Node(i);
    }

    for (int i = 1; i <= n; ++i) {
        int neighbor;
        while (cin >> neighbor && neighbor != -1) {
            nodeMap[i]->neighbors.push_back(nodeMap[neighbor]);
        }
    }

    return nodeMap[1];
}

void printGraph(Node* node) {
    if (!node) return;
    for (auto& neighbor : node->neighbors) {
        printGraph(neighbor);  
    }
}

int main() {
    int n;
    cin >> n;

    Node* graph = createGraph(n);
    
    Solution solution;

    Node* clonedGraph = solution.cloneGraph(graph);

    printGraph(graph);
    printGraph(clonedGraph);

    return 0;
}
