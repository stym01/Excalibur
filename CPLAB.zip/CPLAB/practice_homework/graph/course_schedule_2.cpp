#include <iostream>
#include <vector>
#include <queue>
using namespace std;

class Solution {
public:
    vector<int> findOrder(int numCourses, vector<vector<int>>& prerequisites) {
        int V = numCourses;
        vector<int> adj[V];
        for (auto it : prerequisites) {
            adj[it[1]].push_back(it[0]);
        }
        
        queue<int> q;
        vector<int> inorder(V, 0);
        
        for (int i = 0; i < V; i++) {
            for (auto it : adj[i]) {
                inorder[it]++;
            }
        }
        
        for (int i = 0; i < V; i++) {
            if (inorder[i] == 0) {
                q.push(i);
            }
        }
        
        vector<int> ans;
        
        while (!q.empty()) {
            int x = q.front();
            ans.push_back(x);
            q.pop();
            
            for (auto it : adj[x]) {
                inorder[it]--;
                if (inorder[it] == 0) {
                    q.push(it);
                }
            }
        }
        
        if (ans.size() == V) return ans;
        return {};
    }
};

int main() {
    Solution solution;
    int numCourses;
    cin >> numCourses;
    
    int n;
    cin >> n;
    vector<vector<int>> prerequisites(n, vector<int>(2));
    
    for (int i = 0; i < n; i++) {
        cin >> prerequisites[i][0] >> prerequisites[i][1];
    }
    
    vector<int> result = solution.findOrder(numCourses, prerequisites);
    
    if (result.empty()) {
        cout << "It is not possible to finish all courses." << endl;
    } else {
        cout << "Course order: ";
        for (int course : result) {
            cout << course << " ";
        }
        cout << endl;
    }
    
    return 0;
}
