#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

class Solution {
public:
    vector<int> eventualSafeNodes(vector<vector<int>>& graph) {
        int V = graph.size();
        vector<int> adj[V];
        for (int i = 0; i < V; i++) {
            for (auto it : graph[i]) {
                adj[it].push_back(i);
            }
        }
        queue<int> q;
        vector<int> inorder(V, 0);
        for (int i = 0; i < V; i++) {
            for (auto it : adj[i]) {
                inorder[it]++;
            }
        }
        for (int i = 0; i < V; i++) {
            if (inorder[i] == 0) {
                q.push(i);
            }
        }
        vector<int> ans;
        while (!q.empty()) {
            int x = q.front();
            ans.push_back(x);
            q.pop();
            for (auto it : adj[x]) {
                inorder[it]--;
                if (inorder[it] == 0) {
                    q.push(it);
                }
            }
        }
        sort(ans.begin(), ans.end());
        return ans;
    }
};

int main() {
    int n;
    cin >> n;
    vector<vector<int>> graph(n);

    for (int i = 0; i < n; i++) {
        int m;
        cin >> m;
        graph[i].resize(m);
        for (int j = 0; j < m; j++) {
            cin >> graph[i][j];
        }
    }

    Solution solution;
    vector<int> result = solution.eventualSafeNodes(graph);
    
    for (int i = 0; i < result.size(); i++) {
        cout << result[i] << " ";
    }
    cout << endl;

    return 0;
}
