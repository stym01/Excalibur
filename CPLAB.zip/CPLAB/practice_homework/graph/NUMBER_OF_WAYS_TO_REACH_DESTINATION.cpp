#include <iostream>
#include <vector>
#include <queue>
#include <climits>
using namespace std;

class Solution {
public:
    int countPaths(int n, vector<vector<int>>& roads) {
        const int MOD = 1e9 + 7;
        vector<vector<pair<int, int>>> adj(n);

        for (auto& val : roads) {
            adj[val[0]].push_back({val[1], val[2]});
            adj[val[1]].push_back({val[0], val[2]});
        }

        priority_queue<pair<long long, int>, vector<pair<long long, int>>, greater<pair<long long, int>>> q;
        vector<long long> dis(n, LLONG_MAX);
        vector<long long> cal(n, 0);

        dis[0] = 0;
        cal[0] = 1;
        q.push({0, 0});

        while (!q.empty()) {
            auto val = q.top();
            q.pop();
            int node = val.second;
            long long d = val.first;

            if (d > dis[node]) continue; 

            for (auto& v : adj[node]) {
                int nval = v.first;
                long long wt = v.second;
                long long newd = d + wt;

                if (newd < dis[nval]) {
                    dis[nval] = newd;
                    cal[nval] = cal[node];
                    q.push({dis[nval], nval});
                } 
                else if (newd == dis[nval]) {
                    cal[nval] = (cal[nval] + cal[node]) % MOD;
                }
            }
        }

        return cal[n - 1];
    }
};

int main() {
    int n, m;
    cin >> n >> m;  // Read number of nodes and number of roads
    vector<vector<int>> roads(m, vector<int>(3));

    for (int i = 0; i < m; i++) {
        cin >> roads[i][0] >> roads[i][1] >> roads[i][2];  // Read each road (start node, end node, weight)
    }

    Solution solution;
    cout << solution.countPaths(n, roads) << endl;  // Output the result
    return 0;
}
