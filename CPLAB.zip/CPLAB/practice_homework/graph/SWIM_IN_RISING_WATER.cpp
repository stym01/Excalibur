#include <iostream>
#include <vector>
#include <queue>
using namespace std;

class Solution {
public:
    int swimInWater(vector<vector<int>>& grid) {
        priority_queue<pair<int, pair<int, int>>, vector<pair<int, pair<int, int>>>, greater<pair<int, pair<int, int>>>> q;
        int n = grid.size();
        int m = grid[0].size();
        q.push({grid[0][0], {0, 0}});
        vector<vector<int>> vis(n, vector<int>(m, 0));
        
        int t = 0;
        vector<pair<int, int>> dir = {{0, 1}, {1, 0}, {-1, 0}, {0, -1}};
        while (!q.empty()) {
            int val = q.top().first;
            int i = q.top().second.first;
            int j = q.top().second.second;
            q.pop();
            if (vis[i][j]) continue;
            vis[i][j] = 1;
            t = max(t, val);
            if (i == n - 1 && j == m - 1) return t;
            for (auto& k : dir) {
                int x = i + k.first;
                int y = j + k.second;
                if (x >= 0 && y >= 0 && x < n && y < m && !vis[x][y]) {
                    q.push({grid[x][y], {x, y}});
                }
            }
        }
        return t;
    }
};

int main() {
    int n;
    cin >> n;
    
    vector<vector<int>> grid(n, vector<int>(n));
    
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> grid[i][j];
        }
    }
    
    Solution solution;
    int result = solution.swimInWater(grid);
    cout << result << endl;

    return 0;
}
