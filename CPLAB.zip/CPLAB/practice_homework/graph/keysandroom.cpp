#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    void cal(int node, vector<vector<int>>& rooms, vector<bool>& vis) {
        vis[node] = true;
        for (auto& val : rooms[node]) {
            if (!vis[val]) {
                cal(val, rooms, vis);
            }
        }
    }
    
    bool canVisitAllRooms(vector<vector<int>>& rooms) {
        vector<bool> vis(rooms.size(), false);
        cal(0, rooms, vis);
        for (auto val : vis) {
            if (!val) return false;
        }
        return true;
    }
};

int main() {
    int n;
    cin >> n;
    vector<vector<int>> rooms(n);

    for (int i = 0; i < n; i++) {
        int m;
        cin >> m;
        rooms[i].resize(m);
        for (int j = 0; j < m; j++) {
            cin >> rooms[i][j];
        }
    }

    Solution solution;
    bool result = solution.canVisitAllRooms(rooms);
    cout << (result ? "YES" : "NO") << endl;

    return 0;
}
