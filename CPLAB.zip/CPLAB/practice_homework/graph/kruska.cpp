#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class DisjointSet {
public:
    vector<int> parent, size;

    DisjointSet(int n) {
        parent.resize(n);
        size.resize(n, 1);
        for (int i = 0; i < n; i++) {
            parent[i] = i;
        }
    }

    int findParent(int u) {
        if (parent[u] != u) {
            parent[u] = findParent(parent[u]);
        }
        return parent[u];
    }

    void unionSets(int u, int v) {
        int rootU = findParent(u);
        int rootV = findParent(v);

        if (rootU != rootV) {
            if (size[rootU] > size[rootV]) {
                parent[rootV] = rootU;
                size[rootU] += size[rootV];
            } else {
                parent[rootU] = rootV;
                size[rootV] += size[rootU];
            }
        }
    }
};

struct Edge {
    int u, v, weight;
    Edge(int u, int v, int weight) : u(u), v(v), weight(weight) {}

    bool operator<(const Edge& other) const {
        return weight < other.weight;
    }
};

class Kruskal {
public:
    int kruskalMST(int n, vector<Edge>& edges) {
        DisjointSet ds(n);
        sort(edges.begin(), edges.end());

        int mstWeight = 0;
        vector<Edge> mstEdges;

        for (const auto& edge : edges) {
            int u = edge.u;
            int v = edge.v;

            if (ds.findParent(u) != ds.findParent(v)) {
                ds.unionSets(u, v);
                mstWeight += edge.weight;
                mstEdges.push_back(edge);
            }
        }

        cout << "Edges in MST:" << endl;
        for (const auto& edge : mstEdges) {
            cout << edge.u << " - " << edge.v << " : " << edge.weight << endl;
        }

        return mstWeight;
    }
};

int main() {
    int n = 4;
    vector<Edge> edges;

    edges.push_back(Edge(0, 1, 10));
    edges.push_back(Edge(0, 2, 6));
    edges.push_back(Edge(0, 3, 5));
    edges.push_back(Edge(1, 3, 15));
    edges.push_back(Edge(2, 3, 4));

    Kruskal kruskal;
    int mstWeight = kruskal.kruskalMST(n, edges);

    cout << "Total weight of MST: " << mstWeight << endl;

    return 0;
}
