#include <bits/stdc++.h>
using namespace std;
int partition(int arr[],int low,int high){
    int pivot=arr[high];
    int i=low-1;
    for(int j=low;j<high;j++){
        if(arr[j]<=pivot){
            i++;
            swap(arr[i],arr[j]);
        }
    }
    swap(arr[i+1],arr[high]);
    return i+1;
}
int kthsmallest(int arr[],int low,int high,int k){
    if(k>0 && k<=high-low+1){
        int pos=partition(arr,low,high);
        if(pos-low+1==k){
            return arr[pos];
        }
        if(pos-low>k-1){
            return kthsmallest(arr,low,pos-1,k);
        }
        return kthsmallest(arr,pos+1,high,k-pos+low-1);
    }
    return INT_MAX;
}
int main(){
   int t;
   cin>>t;
   while(t--){
       int n,k;
       cin>>n;
       int arr[n];
       for(int i=0;i<n;i++){
           cin>>arr[i];
       }
       cin>>k;
       cout<<kthsmallest(arr,0,n-1,k)<<endl;
   }
    return 0;
}