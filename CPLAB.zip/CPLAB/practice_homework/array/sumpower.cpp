#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void solve(){
    int t;
	cin>>t;
	while(t--){
	   ll n,k;
	   cin>>n>>k;
	   string s;
	   cin>>s;
       long ans=0;
       vector<int> prefix(n+1,0);
	   for(int i=0;i<n;i++){
        if(s[i]!=s[i+1]){
            prefix[i+1]=prefix[i]+1;
        }
        else{
            prefix[i+1]=prefix[i];
        }
       }
       for(int i=k;i<n;i++){
        ans += prefix[i]-prefix[i-k];
       }
       cout<<ans<<endl;
	}
}
int main() {
	solve();

}