#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;
    while (T--) {
        long long N, P, K;
        cin >> N >> P >> K;

        
        if (N <= 0 || P <= 0 || K < 0 || N > 1e5 || P > 1e5 || K > P) {
            cout << "NO" << endl;
            continue;
        }

        vector<long long> heights;
        heights.reserve(N);  

        for (long long i = 0; i < N; i++) {
            long long h;
            cin >> h;
            heights.push_back(h);
        }

        sort(heights.begin(), heights.end());

        long long lastRowSize = N % P;

        if (lastRowSize != 0 && lastRowSize > K) {
            cout << "NO" << endl;
            continue;
        }

        bool valid = true;
           long long j=P-1;
           long long size= N/P;
        for (long long i = 0; i <size-1; i ++) {
            if (heights[j] >= heights[j + 1]) {
                valid = false;
                break;
            }
            j+=P;
        }

        cout << (valid ? "YES" : "NO") << endl;
    }
    return 0;
}
