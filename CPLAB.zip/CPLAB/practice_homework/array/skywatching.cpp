#include <bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;

    while (T--) {
        int N, L;
        cin >> N >> L;

        vector<int> v(N);
        for (int i = 0; i < N; i++) {
            cin >> v[i];
        }

        
        sort(v.begin(), v.end());

        long long coor = 0; 
        int maxStars = 0;   

        for (int i = 0; i < N; i++) {
           
            int idx = lower_bound(v.begin() + i, v.end(), v[i] + L + 1) - v.begin();
            int stars = idx - i;

            
            if (stars > maxStars || (stars == maxStars && v[i] > coor)) {
                maxStars = stars;
                coor = v[i];
            }
        }

        cout << maxStars << " " << coor << endl;
    }

    return 0;
}
