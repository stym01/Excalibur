#include <iostream>
#include <cmath>
using namespace std;

class Solution {
public:
    int findComplement(int num) {
       
        int mask = 1;
        while (mask <= num) {
            mask <<= 1;
        }
        
       
        return (mask - 1) ^ num;
    }
};

int main() {
    Solution solution;
    int num;
    
    cout << "Enter a number: ";
    cin >> num;

    int result = solution.findComplement(num);
    cout << "The complement of " << num << " is: " << result << endl;

    return 0;
}
