#include <iostream>
using namespace std;

class Solution {
public:
    bool isPowerOfTwo(int n) {
        if (n == 0) {
            return false;
        }
        long long a = n;
        long long b, c;
        
        b = a - 1;
        c = a & b;
        if (c == 0) {
            return true;
        } else {
            return false;
        }
    }
};

int main() {
    Solution solution;
    int n;
    
    cout << "Enter a number: ";
    cin >> n;
    
    if (solution.isPowerOfTwo(n)) {
        cout << n << " is a power of two." << endl;
    } else {
        cout << n << " is not a power of two." << endl;
    }
    
    return 0;
}
