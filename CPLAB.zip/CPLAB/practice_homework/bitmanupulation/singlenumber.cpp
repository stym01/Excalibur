#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    int singleNumber(vector<int>& nums) {
        int x = nums[0];
        for (int i = 1; i < nums.size(); i++) {
            x = x ^ nums[i];
        }
        return x; 
    }
};

int main() {
    Solution solution;
    vector<int> nums;
    int n, value;
    
    cout << "Enter the number of elements: ";
    cin >> n;
    
    cout << "Enter the elements: ";
    for(int i = 0; i < n; i++) {
        cin >> value;
        nums.push_back(value);
    }
    
    cout << "The single number is: " << solution.singleNumber(nums) << endl;
    
    return 0;
}
