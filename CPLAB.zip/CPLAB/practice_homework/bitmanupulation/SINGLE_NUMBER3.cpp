#include <iostream>
#include <vector>
using namespace std;

class Solution {
public:
    vector<int> singleNumber(vector<int>& nums) {
        long x = nums[0];
        vector<int> ans;
        for (int i = 1; i < nums.size(); i++) {
            x = x ^ nums[i];
        }
        int rightmost = (x & (x - 1)) ^ x;
        int b1 = 0, b2 = 0;
        for (int i = 0; i < nums.size(); i++) {
            if (nums[i] & rightmost) {
                b1 = b1 ^ nums[i];
            }
            else {
                b2 = b2 ^ nums[i];
            }
        }

        return {b1, b2};
    }
};

int main() {
    Solution solution;
    vector<int> nums;
    int n, val;
    
    cout << "Enter the number of elements: ";
    cin >> n;
    
    cout << "Enter the elements: ";
    for (int i = 0; i < n; i++) {
        cin >> val;
        nums.push_back(val);
    }

    vector<int> result = solution.singleNumber(nums);
    cout << "The two single numbers are: " << result[0] << " and " << result[1] << endl;

    return 0;
}
