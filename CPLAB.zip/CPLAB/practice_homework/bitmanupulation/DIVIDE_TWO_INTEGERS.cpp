#include <iostream>
#include <climits>
#include <cmath>
using namespace std;

class Solution {
public:
    int divide(int divident, int divisor) {
        if(divident == divisor) return 1;
        bool sign = true;
        if(divident >= 0 && divisor < 0) sign = false;
        if(divident <= 0 && divisor > 0) sign = false;
        
        long n = labs(divident);
        long d = labs(divisor);
        long ans = 0;
        
        while(n >= d){
            int count = 0;
            while(n >= (d << (count + 1))){
                count++;
            }
            ans += (1 << count);
            n -= (d << count);
        }
        
        if(ans == (1 << 31) && sign) return INT_MAX;
        if(ans == (1 << 31) && !sign) return INT_MIN;
        return sign ? ans : -ans;
    }
};

int main() {
    Solution obj;
    int dividend, divisor;
    
   
    cout << "Enter dividend: ";
    cin >> dividend;
    
    cout << "Enter divisor: ";
    cin >> divisor;
    
    
    int result = obj.divide(dividend, divisor);
    cout << "Result of division: " << result << endl;
    
    return 0;
}
