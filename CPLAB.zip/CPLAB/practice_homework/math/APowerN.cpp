#include<iostream>
using namespace std;
 
long long pow(long long a, long long n){
    long long result = 1;
    while(n){
        if(n & 1)
            result *= a;
        a *= a;
        n >>= 1;
    }
    return result;
}
int main(){
    long long a, n;
    cin >> a >> n;
    cout << pow(a, n) << "\n";
    return 0;
}
