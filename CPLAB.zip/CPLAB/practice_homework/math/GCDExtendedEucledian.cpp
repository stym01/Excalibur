
#include<iostream>
using namespace std;
int gcd_Extended(int a, int b, int& x, int& y)
{
    if(a==0)
    {
        x=0;
        y=1;
        return b;
    }
    int x1, y1;
    int gcd=gcd_Extended(b%a, a, x1, y1);
    x=y1-(b/a)*x1;
    y=x1;
    return gcd;
}
int main()
{
    cout<<"Enter two numbers"<<endl;
    int a,b;
    cin>>a>>b;
    int x,y;
    int gcd=gcd_Extended(a,b,x,y);
    cout<<"GCD of "<<a<<" and "<<b<<" is: "<<gcd<<endl;
    cout<<"x: "<<x<<" y: "<<y<<endl;
    return 0;
}