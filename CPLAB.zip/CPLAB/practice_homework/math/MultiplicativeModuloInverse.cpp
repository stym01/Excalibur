#include<iostream>
using namespace std;
int gcdExtendedEucledian(int a,int b,int *x,int *y)
{
    if(a==0)
    {
        *x=0;
        *y=1;
        return b;
    }
    int x1, y1;
    int gcd=gcdExtendedEucledian(b%a, a, &x1, &y1);
    *x=y1-(b/a)*x1;
    *y=x1;
    return gcd;
}
int MultiplicativeModuloInverse(int a,int m)
{
    int x,y;
    int ans=gcdExtendedEucledian(a,m,&x,&y);
    if(ans!=1) 
    {
        cout<<"Multiplicative Modular Inverse does not exist."<<endl;
        return -1;
    }
    int gcd=(x%m+m)%m;
    return gcd;
}
int main()
{
    int a,m;
    cout<<"Enter the value of a and m"<<endl;
    cin>>a>>m;
    int ans=MultiplicativeModuloInverse(a,m);
    if(ans!=-1)
    {
        cout<<"The value of x is "<<ans<<endl;
    }
    return 0;
}
