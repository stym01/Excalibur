#include<iostream>
using namespace std;
int power(int x,int y,int p)
{
    int res=1;
    x=x%p;
    if(x==0)
    {
        return 0;
    }
    while(y>0)
    {
        if(y&1)
        {
            res=(res*x)%p;
            y=y>>1;
            x=(x*x)%p;
        }
    }
    return res;
}
int main()
{
    int x,y,p;
    cout<<"Enter the value of x,y and p"<<endl;
    cin>>x>>y>>p;
    cout<<"The value of x^y mod p is "<<power(x,y,p)<<endl;
    return 0;
}