#include <iostream>
#include <unordered_map>
using namespace std;

struct ListNode {
    int val;
    ListNode *next;
    ListNode(int x) : val(x), next(nullptr) {}
};

class Solution {
public:
    bool hasCycle(ListNode *head) {
      
        // unordered_map<ListNode*, int> m;
        // ListNode* temp = head;
        // while (temp) {
        //     m[temp]++;
        //     if (m[temp] > 1) {
        //         return true;  // Cycle detected
        //     }
        //     temp = temp->next;
        // }
        // return false;  // No cycle

       
        ListNode* slow = head;
        ListNode* fast = head;
        
        while (fast && fast->next) {
            slow = slow->next;
            fast = fast->next->next;
            if (slow == fast) return true;
        }
        
        return false;
    }
};

int main() {
    Solution obj;
    
   
    ListNode* head1 = new ListNode(1);
    head1->next = new ListNode(2);
    head1->next->next = new ListNode(3);
    head1->next->next->next = new ListNode(4);

    
    ListNode* head2 = new ListNode(1);
    head2->next = new ListNode(2);
    head2->next->next = new ListNode(3);
    head2->next->next->next = new ListNode(4);
    head2->next->next->next->next = head2->next; 

    cout << "Does the first list have a cycle? " << (obj.hasCycle(head1) ? "Yes" : "No") << endl;
    cout << "Does the second list have a cycle? " << (obj.hasCycle(head2) ? "Yes" : "No") << endl;

    return 0;
}
