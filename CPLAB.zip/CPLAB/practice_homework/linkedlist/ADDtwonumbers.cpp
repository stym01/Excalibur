#include <iostream>
using namespace std;

struct ListNode {
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};

class Solution {
public:
    ListNode* addTwoNumbers(ListNode* l1, ListNode* l2) {
        int sum = 0, carry = 0;
        ListNode* head = NULL, *temp = NULL;
        
        while (l1 && l2) {
            sum = l1->val + l2->val + carry;
            carry = sum / 10;
            sum = sum % 10;
            
            if (!head) {
                head = new ListNode(sum);
                temp = head;
            } else {
                temp->next = new ListNode(sum);
                temp = temp->next;
            }

            l1 = l1->next;
            l2 = l2->next;
        }

        while (l1) {
            sum = l1->val + carry;
            carry = sum / 10;
            sum = sum % 10;
            temp->next = new ListNode(sum);
            temp = temp->next;
            l1 = l1->next;
        }

        while (l2) {
            sum = l2->val + carry;
            carry = sum / 10;
            sum = sum % 10;
            temp->next = new ListNode(sum);
            temp = temp->next;
            l2 = l2->next;
        }

        if (carry) {
            temp->next = new ListNode(carry);
        }
        temp->next = NULL;
        
        return head;
    }
};

int main() {
    Solution obj;
    int n1, n2, value;

    // Input for first linked list (l1)
    cout << "Enter the number of elements in the first linked list: ";
    cin >> n1;
    
    ListNode* l1 = NULL;
    ListNode* tail1 = NULL;
    
    cout << "Enter the elements of the first linked list: ";
    for (int i = 0; i < n1; i++) {
        cin >> value;
        ListNode* newNode = new ListNode(value);
        if (l1 == NULL) {
            l1 = newNode;
            tail1 = newNode;
        } else {
            tail1->next = newNode;
            tail1 = newNode;
        }
    }

    // Input for second linked list (l2)
    cout << "Enter the number of elements in the second linked list: ";
    cin >> n2;
    
    ListNode* l2 = NULL;
    ListNode* tail2 = NULL;
    
    cout << "Enter the elements of the second linked list: ";
    for (int i = 0; i < n2; i++) {
        cin >> value;
        ListNode* newNode = new ListNode(value);
        if (l2 == NULL) {
            l2 = newNode;
            tail2 = newNode;
        } else {
            tail2->next = newNode;
            tail2 = newNode;
        }
    }

   
    ListNode* result = obj.addTwoNumbers(l1, l2);

    
    cout << "The sum of the two linked lists is: ";
    ListNode* temp = result;
    while (temp != NULL) {
        cout << temp->val << " ";
        temp = temp->next;
    }
    cout << endl;

    return 0;
}
