#include <iostream>
using namespace std;

struct ListNode {
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};

class Solution {
public:
    ListNode* middleNode(ListNode* head) {
        ListNode* slow = head;
        ListNode* fast = head;
        while (fast && fast->next) {
            slow = slow->next;
            fast = fast->next->next;
        }
        return slow;
    }
};

int main() {
    Solution obj;

    int n;
    cout << "Enter the number of elements in the linked list: ";
    cin >> n;

    if (n == 0) {
        cout << "The list is empty!" << endl;
        return 0;
    }

    int value;
    cout << "Enter the elements of the linked list: ";
    ListNode* head = nullptr;
    ListNode* tail = nullptr;

    for (int i = 0; i < n; i++) {
        cin >> value;
        ListNode* newNode = new ListNode(value);

        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    // Find and print the middle node
    ListNode* middle = obj.middleNode(head);
    cout << "The middle node value is: " << middle->val << endl;

    return 0;
}
