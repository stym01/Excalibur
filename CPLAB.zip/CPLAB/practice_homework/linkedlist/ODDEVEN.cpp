#include <iostream>
using namespace std;

struct ListNode {
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};

class Solution {
public:
    ListNode* oddEvenList(ListNode* head) {
        if (!head || !head->next) return head;
        ListNode* odd = head;
        ListNode* even = head->next;
        ListNode* evenhead = even;
        while (even && even->next) {
            odd->next = even->next;
            odd = odd->next;
            even->next = odd->next;
            even = even->next;
        }
        odd->next = evenhead;
        return head;
    }
};

int main() {
    Solution obj;
    int n, value;

    cout << "Enter the number of elements in the linked list: ";
    cin >> n;
    
    ListNode* head = NULL;
    ListNode* tail = NULL;
    
    cout << "Enter the elements of the linked list: ";
    for (int i = 0; i < n; i++) {
        cin >> value;
        ListNode* newNode = new ListNode(value);
        if (head == NULL) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    
    ListNode* result = obj.oddEvenList(head);

    
    cout << "The rearranged linked list is: ";
    ListNode* temp = result;
    while (temp != NULL) {
        cout << temp->val << " ";
        temp = temp->next;
    }
    cout << endl;

    return 0;
}
