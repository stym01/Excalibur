#include <bits/stdc++.h>
using namespace std;
 
struct ListNode {
    int val;
     ListNode *next;
     ListNode() : val(0), next(nullptr) {}
     ListNode(int x) : val(x), next(nullptr) {}
     ListNode(int x, ListNode *next) : val(x), next(next) {}
  };
 

  ListNode* findMiddle(ListNode* head){
   
    if (head == nullptr || head->next == nullptr) {
        return head;
    }

    
    ListNode* slow = head;
    ListNode* fast = head->next;

   
    while (fast != nullptr && fast->next != nullptr) {
        slow = slow->next;
        fast = fast->next->next;
    }

    return slow;
}

    ListNode* merge(ListNode* left, ListNode* right) {
        ListNode* dummy = new ListNode(0);
        ListNode* curr = dummy;
        
        while (left && right) {
            if (left->val <= right->val) {
                curr->next = left;
                curr = curr->next;
                left = left->next;
            } else {
                curr->next = right;
                curr = curr->next;
                right = right->next;
            }
        }
        
        while (left) {
            curr->next = left;
            curr = curr->next;
            left = left->next;
        }
        
        while (right) {
            curr->next = right;
            curr = curr->next;
            right = right->next;
        }
        
        return dummy->next;
    }

   ListNode* mergesort(ListNode* head) {
    if (head == nullptr || head->next == nullptr) return head;
    
    ListNode* middle = findMiddle(head);
    ListNode* right = middle->next;
    middle->next = nullptr;
    
    ListNode* left = mergesort(head);
    right = mergesort(right);
    
    return merge(left, right);
}

ListNode* sortList(ListNode* head) {
        return mergesort(head);
    }
int main(){
    int t;
    cin>> t;
    while(t--){
        int n;
        cin>> n;
        ListNode* head=new ListNode();
        ListNode* temp=head;
        for(int i=0;i<n;i++){
            int x;
            cin>> x;
            temp->val=x;
            temp->next=new ListNode();
            temp=temp->next;
        }
        ListNode* ans=sortList(head);
        while(ans!=nullptr){
            cout<< ans->val << " ";
            ans=ans->next;
        }
        cout<<endl;

    }
    return 0;
}

