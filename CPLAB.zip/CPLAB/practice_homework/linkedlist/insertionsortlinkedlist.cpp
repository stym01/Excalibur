#include <iostream>
using namespace std;

struct ListNode {
    int val;
    ListNode* next;
    ListNode(int x) : val(x), next(NULL) {}
};

ListNode* insertionSortList(ListNode* head) {
    ListNode* dummy = new ListNode(-1);
    ListNode* curr = head;

    while (curr != NULL) {
        ListNode* temp = curr->next;
        ListNode* prev = dummy;
        ListNode* nxt = dummy->next;

        while (nxt != NULL) {
            if (nxt->val > curr->val)
                break;
            prev = nxt;
            nxt = nxt->next;
        }

        curr->next = nxt;
        prev->next = curr;
        curr = temp;
    }

    return dummy->next;
}

void printList(ListNode* head) {
    while (head) {
        cout << head->val << " ";
        head = head->next;
    }
    cout << endl;
}

ListNode* pushBack(ListNode* head, int val) {
    ListNode* newNode = new ListNode(val);
    if (!head) return newNode;
    ListNode* temp = head;
    while (temp->next) temp = temp->next;
    temp->next = newNode;
    return head;
}

int main() {
    int n;
    cout << "Enter number of elements: ";
    cin >> n;

    ListNode* head = NULL;
    cout << "Enter elements:\n";
    for (int i = 0; i < n; ++i) {
        int val;
        cin >> val;
        head = pushBack(head, val);
    }

    cout << "Original List: ";
    printList(head);

    head = insertionSortList(head);

    cout << "Sorted List: ";
    printList(head);

    return 0;
}
