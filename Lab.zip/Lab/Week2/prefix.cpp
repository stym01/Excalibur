#include<iostream>
#include<vector>
using namespace std;

int prefix_Sum(vector<int>&arr,int n){
    int ans=INT_MIN,sum=0;
    for(int i=0;i<arr.size();i++){
            sum+=arr[i];
            ans=max(sum,ans);
        }
    return ans;
}

int main(){

    int NoOfTestCases;
    cout<<"No of Test cases";
    cin>>NoOfTestCases;
    while(NoOfTestCases--){
        int size;
        cout<<"Enter size: ";
        cin>>size;
        vector<int>arr(size,0);
        
        int NoOfOp;
        cout<<"Enter number of operation";
        cin>>NoOfOp;
        while(NoOfOp--){

            int a,b;
            cout<<"Enter a";
            cin>>a;
            cout<<"Enter b";
            cin>>b;
            if (b<a) swap(a,b);
            
            if (a>0 && a<size){ 
                arr[a]+=100;}
            else cout<<"Not a correct input"; 
            
            if (b+1<size) arr[b+1]-=100;
            else cout<<"Not a correct input"; 
            
        }
            int ans=prefix_Sum(arr,size);
            cout<<ans;
            
    }
    
    return 0;
}


/* 
3
5 3
-1 3  0 7 1 3         

5 3
0 2, 2 4, 1 4
3. n=5, m=3
1 1, 2 2, 3 3


1. 300
2. 300
3. 100
 */