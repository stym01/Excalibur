#include<iostream>
#include<vector>
using namespace std;

int sumOfContiguousSubArray(vector<int>&nums){
    int sum=0,maxSum=INT_MIN;
    for (int i=0;i<nums.size();i++){
        sum+=nums[i];
        maxSum=max(maxSum,sum);
        if(sum<0) sum=0;
    }
    return maxSum;

}

int main(){
    int T;
    cin>>T;
    while(T--){
        int n;
    cin>>n;
    vector<int>nums(n);
    for (int i=0;i<n;i++) cin>>nums[i];
    cout<<sumOfContiguousSubArray(nums)<<endl;
    return 0;

    }
    
}

/*
1. 2 8 -5 1 0 6
2. -6 -4 -2 -1 -6 -5
3. 0 0 0 0 0
4. 9 8 7 5 4
5. 9 -6 5 -10 101
6. []
7. INT_MAX INT_MAX INT_MAX



o/p:
1. 12
2. -1
3. 0
4. 33
5. 101
6. 0
7. INT_MAX
*/