#include<iostream>
#include<stack>
#include <utility>
#include<vector>
using namespace std;

vector<int> stockSpan(vector<int>&nums){
    stack<pair<int,int> >st;
    vector<int>res;
    for (int i=0;i<nums.size();i++){
        while(!st.empty() && st.top().first<nums[i]){
            st.pop();
        }
        
        if (st.empty()){
            res.push_back(i+1);
        }
        else res.push_back(i-st.top().second);
        st.push(make_pair(nums[i],i));
    }
    return res;
}


int main(){
    int T;
    cout<<"T";
    cin>>T;
    while(T--){
        int n;
        cin>>n;
        vector<int>arr(n);
        for (int i=0;i<n;i++){
            cin>>arr[i];
        }
        vector<int>ans=stockSpan(arr);
        for (int num:ans) cout<<num<<" ";

    }
    return 0;
}

/*
7
5
100 80 60 70 60 //normal
5
2 4 7 9 10  //inc
5
10 9 6 3 2  dec
5
2 2 2 2 2 //duplicate
5
100 5 50 1 108 //crest and trough
6
100 2 50 1000 20 10 //peak and valley
*/

/*
1 1 1 2 1 
1 2 3 4 5
1 1 1 1 1 
1 1 1 1 1 
1 1 2 1 5 
1
1 1 2 4 1 1 1 
*/ 



