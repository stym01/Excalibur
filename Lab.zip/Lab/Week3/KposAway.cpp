#include<iostream>
#include<vector>
using namespace std;

int findK(vector<int>&nums,int target){
    int low=0,high=nums.size()-1;
    while(low<=high){
        int mid=low+(high-low)/2;
        if (nums[mid]==target) return mid;
        else if (nums[low]<=nums[mid]){
            if (nums[low]<=target && target<=nums[mid]) high=mid-1;
            else low=mid+1;
        }
        else {
            if (nums[mid]<=target && target<=nums[high]) low=mid+1;
            else high=mid-1;
        }
    }
    return -1;
}

int main(){
    int T;
    cin>>T;
    while(T--){
        int n,k;
        cin>>n>>k;
        vector<int>nums(n);
        for (int i=0;i<n;i++){
            cin>>nums[i];
        }
        int index=findK(nums, k);
        cout<<index<<" ";

    }
    return 0;
}

/*
10

6 3
4 5 6 1 2 3

3 6 
4 5 6 1 2 3

6 2 
1 2 3 4 5 6

6 10 
4 5 6 1 2 3

6 6
6 1 2 3 4 5

6 1
2 3 4 5 6 1

0 1 

2 1 
4 1

1 1 
4

2 1
1 4
*/

/* 
//array is not rotated
//element not present
//only one element
//element not present
*/

/* output:
5
2
1
-1 
0
5
-1 
0
-1 
0
*/