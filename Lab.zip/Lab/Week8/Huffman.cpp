#include<iostream>
#include <queue>
#include <unordered_map>
using namespace std;

struct Node{
    public:
    union{
        struct{
            char ch;
            string* code;
        }leaf;
        struct{
            Node* left;
            Node* right;
        }nonleaf;
    }data;
    int freq;
    bool isLeaf;

    Node(int frequency,Node* left,Node* right){
        data.nonleaf.left=left;
        data.nonleaf.right=right;
        freq=frequency;
        isLeaf=false;
    }
    Node(char ch,int frequency){
        data.leaf.ch=ch;
        data.leaf.code=new string("");
        freq=frequency;
        isLeaf=true;
    }
};

class comparator{
    bool operator()(Node* a,Node* b){
        return a->freq>b->freq;
    }
};

void generateCode(Node* &root,string code){
    if (root==NULL) return;
    if(root->isLeaf){
        *(root->data.leaf.code)=code;
        return;
    }
    generateCode(root->data.nonleaf.left,code+"0");
    generateCode(root->data.nonleaf.right,code+"1");

}

void huffman(string &s){
    unordered_map<int,int>mp;
    for(auto c:s) mp[c]++;

    priority_queue<Node*,vector<Node*>,comparator>pq;
    for (auto i:mp) pq.push(new Node(i.first,i.second));

    while(pq.size()>1){
        Node* left=pq.top();pq.pop();
        Node* right=pq.top();pq.pop();
        Node* nn=new Node(left->freq+right->freq,left,right);
        pq.push(nn);
    }

    Node* root=pq.top();
    generateCode(root,"");
    queue<Node*>q;
    q.push(root);
    while(!q.empty()){
        Node* curr=q.front();
        q.pop();
        if(curr->isLeaf){
            cout<<curr->data.leaf.ch<<"->"<<*(curr->data.leaf.code)<<endl;
        }
        else {
            q.push(curr->data.nonleaf.left);
            q.push(curr->data.nonleaf.right);
        }
    }
}

int main() {
    string input;
    cout << "Enter a string to encode using Huffman Coding: ";
    getline(cin, input);

    if (input.empty()) {
        cout << "Input string is empty." << endl;
        return 0;
    }

    huffman(input);

    return 0;
}

/*
abcde
a
abb
aaaa
hello world
aaaaaabbbbzzzzzzkkkl
" "

*/