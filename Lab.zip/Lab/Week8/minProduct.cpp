#include<iostream>
#include<vector>
using namespace std;

//Brute force
void function(int ind,int product,int& minProduct,vector<int> &nums){
    if (ind==nums.size()){
        if (product!=1){
            minProduct=min(product,minProduct);
        }
        return;
    }
    //pick
    function(ind+1,product*nums[ind],minProduct,nums);
    //non pick
    function(ind+1,product,minProduct,nums);
}
int minProduct1(vector<int>&nums){
    int minProduct=INT_MAX;
    function(0,1,minProduct,nums);
    return minProduct;
}

int minProduct2(vector<int>&nums){
    int neg_count=0,zero_count=0,pos_count=0,max_neg=INT_MIN,min_pos=INT_MAX;
    int n=nums.size();
    int product=1;
    for (int i=0;i<nums.size();i++){
        if (nums[i]<0){
            neg_count++;
            max_neg=max(max_neg,nums[i]);
        }
        else if (nums[i]==0){
            zero_count++;
        }
        else{
            pos_count++;
            min_pos=min(nums[i],min_pos);
        }
        if(nums[i]!=0) product*=nums[i];

    }
    if (zero_count==n) return 0;
    if (neg_count==1 && zero_count+neg_count==n) return max_neg;
    if (neg_count%2==0 && neg_count>0) return product/=max_neg;
    if (!neg_count && !zero_count) return min_pos;
    if (!neg_count) return 0;

}

int main(){
    int T;
    cin>>T;
    while(T--){
        int n;
        cin>>n;
        vector<int>vec(n);
        for (int i=0;i<n;i++){
            cin>>vec[i];
        }
        cout<< minProduct1(vec)<<endl;
        cout<< minProduct2(vec);
    }
    return 0;
}

/*
Input:
4
-5 -2 -3 -4

5
0 0 0 0 0

7
0 -2 -1 0 -9 0 -51

3
0 1 7

8
0 -1 2 0 -1000 10 3 4

5
8 2 4 5 10
Output:
-60
-60

0
0

-918
-918

0
0

-240000
-240000

2
2
*/