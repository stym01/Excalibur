#include <iostream>
using namespace std;

int getNextWithSameOnes(int n) {
    if (n == 0) return -1;  
    int c = n;
    int c0 = 0, c1 = 0;
    while ((c & 1) == 0 && c != 0) {
        c0++;
        c >>= 1;
    }
    while ((c & 1) == 1) {
        c1++;
        c >>= 1;
    }
    if (c0 + c1 == 31 || c0 + c1 == 0)
        return -1;
    int pos = c0 + c1;
    n |= (1 << pos);
    n &= ~((1 << pos) - 1);
    n |= (1 << (c1 - 1)) - 1;

    return n;
}

int main() {
    int T;
    cin>>T;
    while(T--){
        int n;
        cin >> n;
        int nextNumber = getNextWithSameOnes(n);
        if (nextNumber == -1) {
            cout << "No next number possible\n";}
        else {
        cout << "Next number with the same number of 1s: " << nextNumber << endl;
       }

    }
    
    return 0;
}

/*

6
4
The number is: 4
The next smallest number having same ones in binary representation is: 8
12
The number is: 12
The next smallest number having same ones in binary representation is: 17
15
The number is: 15
The next smallest number having same ones in binary representation is: 23
16
The number is: 16
The next smallest number having same ones in binary representation is: 32
0
The number is: 0
The next smallest number having same ones in binary representation is: 1
8
The number is: 8
The next smallest number having same ones in binary representation is: 16
*/