#include<iostream>
#include<vector>
using namespace std;

bool iceCream(vector<int>&arr){
    int fives=0,tens=0;
    for (int i=0;i<arr.size();i++){
        if (arr[i]==5){
            fives++;
        }
        else if (arr[i]==10){
            if (fives){
                fives--;
                tens++;
            }
            else return false;
        }
        else {
            if (fives) fives-=3;
            else if (fives && tens){
                fives--;
                tens--;
            }
            else return false;
        }
    }
    return true;
}

int main(){
    int T;
    cin>>T;
    while(T--){
        int n;
        cin>>n;
        vector<int>arr(n);
        for (int i=0;i<n;i++){
            cin>>arr[i];
        }
        if (iceCream(arr)){
            cout<<"YES"<<endl;
        }
        else cout<<"NO"<<endl;
    }
    return 0;
}

/*

//Input
5 5 5 10 15
10 5 5 10 15
5 5 5 10 20 20 10 5
20 10 5 5


//Output
YES
NO
YES
NO

*/