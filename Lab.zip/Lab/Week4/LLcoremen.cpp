#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int val) : data(val), next(nullptr) {}
};

void printList(Node* head) {
    while (head) {
        cout << head->data << " -> ";
        head = head->next;
    }
    cout << "NULL\n";
}

Node* getTail(Node* head) {
    while (head && head->next)
        head = head->next;
    return head;
}

Node* partition(Node* head, Node* tail, Node** newHead, Node** newTail) {
    Node* pivot = tail;
    Node* prev = nullptr, *curr = head, *end = tail;

    Node* newHeadLocal = nullptr, *newTailLocal = tail;
    
    while (curr != pivot) {
        if (curr->data < pivot->data) {
            if (!newHeadLocal)
                newHeadLocal = curr; 
            prev = curr;
            curr = curr->next;
        } else { 
            if (prev)
                prev->next = curr->next;
            Node* temp = curr->next;
            curr->next = nullptr;
            end->next = curr;
            end = curr;
            curr = temp;
        }
    }
    *newHead = newHeadLocal ? newHeadLocal : pivot;
    *newTail = end;
    return pivot;
}

Node* quickSortRecur(Node* head, Node* tail) {
    if (!head || head == tail)
        return head;
    Node *newHead = nullptr, *newTail = nullptr;
    Node* pivot = partition(head, tail, &newHead, &newTail);
    if (newHead != pivot) {
        Node* temp = newHead;
        while (temp->next != pivot)
            temp = temp->next;
        temp->next = nullptr;
        newHead = quickSortRecur(newHead, temp);      
        Node* tempTail = newHead;
        while (tempTail->next)
            tempTail = tempTail->next;
        tempTail->next = pivot;
    }
    pivot->next = quickSortRecur(pivot->next, newTail);

    return newHead;
}

Node* quickSort(Node* head) {
    Node* tail = getTail(head);
    return quickSortRecur(head, tail);
}

void append(Node*& head, int data) {
    if (!head) {
        head = new Node(data);
        return;
    }
    Node* temp = head;
    while (temp->next)
        temp = temp->next;
    temp->next = new Node(data);
}

int main() {
    
    int T;
    cin >> T;
    while(T--){
        Node* head = nullptr;
        int n;
        cin>>n;
        for (int i=0;i<n;i++){
            int data;
            cin>>data;
            append(head, data);
        }
        cout<<"Original List: ";
        printList(head);
        head=quickSort(head);
        cout<<"Sorted List: ";
        printList(head);

    }
    return 0;
}

/*
1

5
2 9 5 1 0

4
1 2 3 4

5 
99 33 22 10 5

2
7 1

1
3

0

7
2555 7777 8888 11 21 32 55*/