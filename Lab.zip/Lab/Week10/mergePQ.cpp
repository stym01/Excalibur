#include<iostream>
#include<queue>
using namespace std;

void heapify(vector<int>&arr,int index,int size){
    int largest=index;
    int left=2*index+1,right=2*index+2;
    if (left<size && arr[left]>arr[largest]) largest=left;
    if (right<size && arr[right]>arr[largest]) largest=right;
    if (largest!=index){
        swap(arr[largest],arr[index]);
        heapify(arr,largest,size);
    }
}

void mergeHeap(vector<int>&a,int m,vector<int>&b,int n){
    a.resize(m+n);
    for (int i=0;i<n;i++) a[i+m]=b[i];
    int size=m+n;
    for(int i=(size/2)-1;i>=0;i--){
        heapify(a,i,size);
    }
}

int main(){
    int m,n;
    cin>>m>>n;
    vector<int>a(m),b(n);
    for(int i=0;i<m;i++) cin>>a[i];
    for(int i=0;i<n;i++) cin>>b[i];
    mergeHeap(a,m,b,n);
    for(int i=0;i<a.size();i++) cout<<a[i]<<" ";
    return 0;
}

/*
Input:
3 3
1 3 5
2 4 6

5 3
10 9 8 7 6
5 4 3

4 2
20 10 15 5
30 25

6 4
1 1 1 1 1 1
2 2 2 2

3 1
100 90 80
110

Output:
6 4 5 1 3 2 
10 9 8 7 6 5 4 3 
30 25 15 5 10 20 
2 2 2 1 1 1 1 1 1 1 
110 100 80 90 


*/