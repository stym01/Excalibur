#include<iostream>
#include<vector>
using namespace std;

class ListNode {
public:
    int data;
    ListNode* next;
    ListNode(int val) {
        data = val;
        next = nullptr;
    }
};

bool cycleDetect(ListNode* head) {
    if (!head) return false;
    ListNode* slow = head, *fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) return true;
    }
    return false;
}

void printList(ListNode* head) {
    int count = 0;
    while (head && count < 100) {
        cout << head->data;
        if (head->next) cout << " -> ";
        head = head->next;
        count++;
    }
    cout << endl;
}

ListNode* createList() {
    int n;
    cin >> n;
    if (n == 0) return nullptr;
    vector<ListNode*> nodes;
    int val;
    cin >> val;
    ListNode* head = new ListNode(val);
    nodes.push_back(head);
    ListNode* temp = head;
    for (int i = 1; i < n; i++) {
        cin >> val;
        temp->next = new ListNode(val);
        temp = temp->next;
        nodes.push_back(temp);
    }
    int pos;
    cin >> pos;
    if (pos != -1 && pos < n) {
        temp->next = nodes[pos];
    }
    return head;
}

int main() {
    ListNode* head = createList();
    printList(head);
    if (cycleDetect(head)) {
        cout << "Cycle detected!" << endl;
    } else {
        cout << "No cycle detected!" << endl;
    }
    return 0;
}

/*
5
1 2 3 4 5
1
3
10 20 30
-1
0

6
1 2 3 4 5 6
0

4
7 8 9 10
2

7
11 12 13 14 15 16 17
6

1
42
-1

8
3 6 9 12 15 18 21 24
-1

9
1 3 5 7 9 11 13 15 17
3


ouput:
1 -> 2 -> 3 -> 4 -> 5
Cycle detected!
10 -> 20 -> 30
No cycle detected!

No cycle detected!
1 -> 2 -> 3 -> 4 -> 5 -> 6
Cycle detected!
7 -> 8 -> 9 -> 10
Cycle detected!
11 -> 12 -> 13 -> 14 -> 15 -> 16 -> 17
Cycle detected!
42
No cycle detected!
3 -> 6 -> 9 -> 12 -> 15 -> 18 -> 21 -> 24
No cycle detected!
1 -> 3 -> 5 -> 7 -> 9 -> 11 -> 13 -> 15 -> 17
Cycle detected!


*/