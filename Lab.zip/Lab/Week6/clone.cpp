#include<iostream>
using namespace std;

struct Node{
    int data;
    Node* next;
    Node* random;
    Node(int val){
        data=val;
        next=nullptr;
    }
};

Node* cloneLL(Node* head){
    if(!head) return nullptr;
    Node* curr=head;
    while(curr){
        Node* copy=new Node(curr->data);
        copy->next=curr->next;
        curr->next=copy;
        curr=copy->next;
    }

    curr=head;
    while(curr){
        if(curr->random){
            curr->next->random=curr->random->next;
        }
        curr=curr->next->next;
    }

    curr=head;
    Node* newHead=head->next;
    while(curr){
        Node* copy=curr->next;
        curr->next=curr->next->next;
        if(copy->next) copy->next=copy->next->next;
        curr=curr->next;
    }
    return newHead;

}


void printList(Node* head) {
    while (head) {
        cout << "Node: " << head->data;
        if (head->random)
            cout << ", Random: " << head->random->data;
        else
            cout << ", Random: NULL";
        cout << endl;
        head = head->next;
    }
}

int main() {
    int n;
    cin >> n;
    vector<Node*> nodes(n);
    for(int i=0; i<n; i++){
        int val;
        cin >> val;
        nodes[i] = new Node(val);
        if(i > 0) nodes[i-1]->next = nodes[i];
    }

    for(int i=0; i<n; i++){
        int idx;
        cin >> idx;
        if(idx >= 0 && idx < n)
            nodes[i]->random = nodes[idx];
    }

    Node* head = nodes[0];

    cout << "Original list:\n";
    printList(head);

    Node* cloned = cloneLL(head);

    cout << "\nCloned list:\n";
    printList(cloned);

    return 0;
}

/*

3
10 20 30
2 0 1

5
1 2 3 4 5
2 1 0 4 3

1
1
0

2
1 2
1 0


Original list:
Node: 10, Random: 30
Node: 20, Random: 10
Node: 30, Random: 20

Cloned list:
Node: 10, Random: 30
Node: 20, Random: 10
Node: 30, Random: 20


Original list:
Node: 1, Random: 3
Node: 2, Random: 2
Node: 3, Random: 1
Node: 4, Random: 5
Node: 5, Random: 4

Cloned list:
Node: 1, Random: 3
Node: 2, Random: 2
Node: 3, Random: 1
Node: 4, Random: 5
Node: 5, Random: 4

Original list:
Node: 1, Random: 1

Cloned list:
Node: 1, Random: 1

Original list:
Node: 1, Random: 2
Node: 2, Random: 1

Cloned list:
Node: 1, Random: 2
Node: 2, Random: 1

*/