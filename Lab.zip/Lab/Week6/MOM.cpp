#include<iostream>
#include<vector>
using namespace std;

int findMedian(vector<int>&arr,int left,int size){
    sort(arr.begin()+left,arr.begin()+left+size);
    return arr[left+size/2];
}
int partition(vector<int>&arr,int left,int right,int pivot){
    int  PivotIndex=find(arr.begin()+left,arr.begin()+right+1,pivot)-arr.begin();
    swap(arr[PivotIndex],arr[right]);
    int i=left;
    for(int j=left;j<right;j++){
        if(arr[j]<=pivot){
            swap(arr[i],arr[j]);
            i++;
        }
    }
    swap(arr[i],arr[right]);
    return i;
}

int kthSmallest(vector<int>&arr,int left,int right,int k){
    if(left==right) return arr[left];
    int n=right-left+1;
    int numMedians=(n+4)/5;
    vector<int>medians(numMedians);
    for(int i=0;i<numMedians;i++){
        int subLeft=left+i*5;
        int subSize=min(5,n-i*5);
        medians[i]=findMedian(arr,subLeft, subSize);
    }
    int medianOfMedians=(numMedians==1)?medians[0]:kthSmallest(medians, 0,numMedians-1,numMedians/2);
    int pos=partition(arr,left,right,medianOfMedians);
    if(pos-left==k-1) return arr[pos];
    else if(pos-left>k-1) return kthSmallest(arr,left,pos-1,k);
    else return kthSmallest(arr, pos+1, right,k-(pos-left+1));
}

int main() {
    int t;
    cin>>t;
    while(t--){
        int n, k;
        cin >> n;
        vector<int> arr(n);
        for (int i = 0; i < n; i++) cin >> arr[i];
        cin >> k;
    
        if (k < 1 || k > n) {
            cout << "Invalid k!" << endl;
            return 1;
        }
    
        int result = kthSmallest(arr, 0, n - 1, k);
        cout << k << "th smallest element is: " << result << endl;
    

    }
 
    return 0;
}

/*
//Input
7
12 3 5 7 4 19 26
3

6
1 2 3 4 5 6
1

6
1 2 3 4 5 6
6

5
9 8 7 6 5
2

10
10 9 8 7 6 5 4 3 2 1
5

1
99
1

5
5 5 5 5 5
3

8
2 3 9 4 1 8 5 7
4

9
-3 -1 -7 0 -2 -9 1 -6 -8
6

10
100 200 300 400 500 600 700 800 900 1000
10
*/

/*
//Output
5
1
6
6
6
99
5
4
-2
1000
*/