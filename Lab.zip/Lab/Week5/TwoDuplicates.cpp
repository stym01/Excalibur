#include <iostream>
#include <vector>
using namespace std;

void findDuplicates(vector<int> &arr) 
{
    int n = arr.size() - 2; 
    int xor_all = 0;

    for (int num : arr) 
        xor_all ^= num;

    for (int i = 1; i <= n; i++) 
        xor_all ^= i;

    int diffBit = xor_all & -xor_all;
    int x = 0, y = 0;

    for (int num : arr) 
    {
        if (num & diffBit) x^= num;
        else y^= num;
    }

    for (int i = 1; i <= n; i++) 
    {
        if (i & diffBit) x^= i;
        else y^= i;
    }

    int countX = 0;
    for (int num : arr) 
        if (num == x) countX++;

    
    // 1if (x==0 && y==0) cout<<"No duplicates!";
    if (countX == 2)
        cout << x << " " << y << endl;
    else
        cout << y << " " << x << endl;
}

int main() 
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        if (n<2) cout<<"Minimum input size should be 4!";
        vector<int> nums(n + 2);
        for (int i = 0; i < n + 2; i++){
            cin >> nums[i];
            if(nums[i]<1 || nums[i]>n){
                cout<<"Provide input in range!";
                break;
            }
        }
        

        findDuplicates(nums);
    }
    return 0;
}


//Test cases

/*
//Input
4
3 2 1 4 3 1

5
1 2 3 4 5 2 1

4 
2 3 1 5 2 1

1
1 0

2
1 2 1 2

1
1 2 1

4
1 2 3 4 3 4 

4
1 2 3 4 1 2

4
1 2 3 4 1 4



*/

/*
//ouput
3 1
1 2
Provide input in range!4 5
Provide input in range!0 1
1 2
Provide input in range!0 2
3 4
1 2
1 4

*/