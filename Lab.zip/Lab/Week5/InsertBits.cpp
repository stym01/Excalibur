#include<iostream>
using namespace std;
 // M mein insert ho raha hai N and i end se start hai 

int insertBits(int M, int N,int i,int j)
{
    int mask=pow(2,j-i+1)-1;
    mask=mask<<i;
    mask=~mask;
    M=M&mask;
    N=N<<i;
    int ans=M|N;
    return ans;
}

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        int M,N;
        cin>>M>>N;
        int i,j;
        cin>>i>>j;
        cout<<insertBits(M,N,i,j)<<endl;
    }
}

//Test cases

/*
Input:
19 15 2 4

30 45 0 0

21 67 0 1

0 0 0 0

0 0 2 5

46 90 2 2

15 19 0 5

*/



/*
Output:
63
63
87
0
0
362
19

*/