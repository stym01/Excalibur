#include<iostream>
#include<vector>
using namespace std;

vector<bool>sieve(int n){
    vector<bool>isPrimes(n+1,true);
    isPrimes[0]=isPrimes[1]=false;
    for (int i=2;i*i<=n;i++){
        if(isPrimes[i]){
            for (int j=i*i;j<=n;j+=i){
                isPrimes[j]=false;
            }
        }
    }
    return isPrimes;
}

int main(){
    int T;
    cin>>T;
    while(T--){
        int m,n;
    cin>>m>>n;
    vector<bool>isPrimes(n+1,true);
    isPrimes=sieve(n);
    for (int i=m;i<n;i++){
        if (isPrimes[i]==true){
            cout<<i<<" ";
        }
    }

    }
    
    return 0;
}

/*
5
4 20
11 40
-1 7
0 5
320 350
*/