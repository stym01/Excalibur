#include<iostream>
#include<vector>
using namespace std;

pair<int,int>pairSum1(vector<int>&nums,int target){
    sort(nums.begin(),nums.end());
    int left=0,right=nums.size()-1;
    while(left<=right){
        int sum=nums[left]+nums[right];
        if (sum==target) return make_pair(nums[left],nums[right]);
        else if(sum<target) left++;
        else right--;
    }
    return make_pair(-1,-1);
}

int main(){
    int T;
    cin>>T;
    while(T--){
        int n;
        cin>>n;
        vector<int>nums(n);
        for (int i=0;i<n;i++) cin>>nums[i];
        int target;
        cin>>target;
        pair<int,int>result=pairSum1(nums,target);
        cout<<result.first<<" "<<result.second<<endl;
    }
    
    return 0;
}

/*
5

10 5
2 3 4 5 6

10 5
6 5 4 3 2

-1 6
8 -9 0 -1 -9 7

0 4
8 -8 7 7

5 6
1 1 3 1 0 9
*/