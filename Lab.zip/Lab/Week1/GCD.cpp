#include<iostream>
using namespace std;

int gcd(int a,int b){
    if (a==0) return b;
    return gcd(b,a%b);
}
int main(){
    int T;
    cin>>T;
    while(T--){
        int a,b;
        cin>>a>>b;
        cout<<gcd(a,b)<<endl;
    }
    return 0;
}

/*
9
10 20
20 10
0 1
2 4
5 10
15 35
-2 4
-2 -4
0 0


10
10
1
2
5
5
-2
-2
0
*/