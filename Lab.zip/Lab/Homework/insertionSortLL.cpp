#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int x) {
        data = x;
        next = nullptr;
    }
};

Node* Insertion_sort(Node* head) {
    if (!head || !head->next) return head;

    Node* sorted = nullptr; 

    while (head) {
        Node* curr = head;
        head = head->next;

        if (!sorted || curr->data < sorted->data) {
            curr->next = sorted;
            sorted = curr;
        } else {
            Node* temp = sorted;
            while (temp->next && temp->next->data < curr->data) {
                temp = temp->next;
            }
            curr->next = temp->next;
            temp->next = curr;
        }
    }

    return sorted;
}

int main() {
    int n;
    cin >> n;

    Node* head = nullptr;
    Node* tail = nullptr;

    for (int i = 0; i < n; i++) {
        int val;
        cin >> val;
        Node* temp = new Node(val);
        if (!head) {
            head = tail = temp;
        } else {
            tail->next = temp;
            tail = temp;
        }
    }

    head = Insertion_sort(head);

    while (head) {
        cout << head->data;
        if (head->next) cout << "->";
        head = head->next;
    }
    cout << endl;

    return 0;
}

/*
/*
//Input
5
4 2 1 3 5

3
10 5 20

1
100

6
9 7 5 3 1 2

4
-3 0 -1 2

2
8 8
*/

/*
//Output
1->2->3->4->5
5->10->20
100
1->2->3->5->7->9
-3->-1->0->2
8->8
*/

