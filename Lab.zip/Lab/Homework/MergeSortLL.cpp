#include<iostream>
using namespace std;
struct Node{
    int data;
    Node* next;
    Node(int val):data(val),next(nullptr){}
};

Node* getMiddle(Node* head){
    if(!head) return head;
    Node* slow=head,*fast=head->next;
    while(fast && fast->next){
        slow=slow->next;
        fast=fast->next->next;
    }
    return slow;
}

Node* merge(Node* left,Node* right){
    if(!left) return right;
    if(!right) return left;
    Node* result=nullptr;
    if(left->data<=right->data){
        result=left;
        result->next=merge(left->next,right);
    }
    else{
        result=right;
        result->next=merge(right->next,left);
    }
    return result;
}

Node* mergeSort(Node* head){
    if(!head || !head->next) return head;
    Node* middle=getMiddle(head);
    Node* nextToMiddle=middle->next;
    middle->next=nullptr;
    Node* left=mergeSort(head);
    Node* right=mergeSort(nextToMiddle);
    return merge(left,right);
}


void printList(Node* head){
    while(head){
        cout << head->data << " ";
        head = head->next;
    }
    cout << endl;
}

void push(Node*& head, int val) {
    Node* newNode = new Node(val);
    newNode->next = head;
    head = newNode;
}

int main() {
    Node* head = nullptr;
    int n, value;    
    cin >> n;    
    for(int i = 0; i < n; ++i) {
        cin >> value;
        push(head, value);
    }

    head = mergeSort(head);

    cout << "Sorted List: ";
    printList(head);

    return 0;
}


/*
6
5 2 9 1 7 3
4
10 20 30 40
5
1 2 3 4 5
3
9 8 7
7
12 3 5 7 4 19 26
6
1 6 3 5 2 4
2
7 3
1
99
4
10 5 3 6
3
5 1 9
*/


/*
1 2 3 5 7 9
10 20 30 40
1 2 3 4 5
7 8 9
3 4 5 7 12 19 26
1 2 3 4 5 6
3 7
99
3 5 6 10
1 5 9*/