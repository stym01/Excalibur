#include<iostream>
#include<vector>
using namespace std;

pair<int,int>bsOnMatrix(vector<vector<int> >&matrix,int target){
    int n=matrix.size(),m=matrix[0].size();
    int row=0,col=m-1;
    while(row<n && col>=0){
        if (matrix[row][col]==target) return make_pair(row,col);
        else if (matrix[row][col]<target) row++;
        else col--;
    }
    return make_pair(-1,-1);
}

int main() {
    int t;
    cin>>t;
    while(t--){
        int n, m, target;
        cin >> n >> m;
        vector<vector<int> > matrix(n, vector<int>(m));
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                cin >> matrix[i][j];
        cin >> target;
    
        pair<int,int> result = bsOnMatrix(matrix, target);
        if (result.first == -1)
            cout << "Element not found\n";
        else
            cout << "Element found at (" << result.first << ", " << result.second << ")\n";
    

    }

    return 0;
}

//Test cases

/*
//Input
3 4
1 4 7 11
2 5 8 12
3 6 9 16
5

3 3
10 20 30
15 25 35
27 29 37
29

2 2
1 2
3 4
5

1 1
42
42

2 3
1 3 5
7 9 11
7

2 3
1 3 5
7 9 11
6

4 4
1 2 3 4
5 6 7 8
9 10 11 12
13 14 15 16
11

4 4
1 2 3 4
5 6 7 8
9 10 11 12
13 14 15 16
17

1 5
1 2 3 4 5
3

3 3
-10 -5 0
1 2 3
4 5 6
-5
*/

/*
//Output
1 1
2 1
-1 -1
0 0
1 0
-1 -1
2 2
-1 -1
0 2
0 1
*/