#include<iostream>
using namespace std;

void swap(vector<int>&arr,int i,int j){
    int temp=arr[i];
    arr[i]=arr[j];
    arr[j]=temp;
}

int partitionNuts(vector<int>&nuts,int low,int high,int pivot){
    int i=low,j=high;
    while(i<=j){
        while(nuts[i]<pivot) i++;
        while(nuts[j]>pivot) j--;
        if(i<=j){
            swap(nuts,i,j);
            i++;
            j--;
        }
    }
    return i;
}

int partitionBolts(vector<int>&bolts,int low,int high,int pivot){
    int i=low,j=high;
    while(i<=j){
        while(bolts[i]<pivot) i++;
        while(bolts[j]>pivot) j--;
        if(i<=j){
            swap(bolts,i,j);
            i++;
            j--;
        }
    }
    return i;
}

void matchNutsAndBolts(vector<int>&nuts,vector<int>&bolts,int low,int high){
    if(low<high){
        int pivot=bolts[low+rand()%(high-low+1)];
        int partitionIndexNuts=partitionNuts(nuts,low,high,pivot);
        int partitionIndexBolts=partitionBolts(bolts,low,high,nuts[partitionIndexNuts-1]);
        matchNutsAndBolts(nuts,bolts,low,partitionIndexNuts-1);
        matchNutsAndBolts(nuts,bolts,partitionIndexBolts,high);
    }
}
void printVector(const vector<int>& arr, const string& label) {
    cout << label << ": ";
    for (int x : arr) cout << x << " ";
    cout << endl;
}

int main() {
    int t;
    cin>>t;
    while(t--){
        int n;
        cin >> n;
    
        vector<int> nuts(n), bolts(n);
    
        for (int i = 0; i < n; i++) {
            cin >> nuts[i];
        }
    
        for (int i = 0; i < n; i++) {
            cin >> bolts[i];
        }
    
        matchNutsAndBolts(nuts, bolts, 0, n - 1);
    
        printVector(nuts, "Nuts");
        printVector(bolts, "Bolts");
    

    }


    return 0;
}


/*
//Input
5
4 2 1 3 5
5 1 3 2 4

4
7 3 1 5
6 8 2 4

6
9 2 4 3 6 5
5 9 4 3 2 6

3
10 5 20
15 10 5

2
8 2
7 3

4
4 7 1 9
5 8 6 10
*/

/*
//Output
Nuts: 1 2 3 4 5
Bolts: 1 2 3 4 5

Nuts: 1 3 5 7
Bolts: 1 2 3 4 5

Nuts: 2 3 4 5 6 9
Bolts: 2 3 4 5 6 9

Nuts: 5 10 20
Bolts: 5 10 15

Nuts: 2 8
Bolts: 3 7

Nuts: 1 4 7 9
Bolts: 5 6 8 10
*/
