#include<iostream>
#include<vector>
using namespace std;
int N;
vector<int>x;

void printSolution(){
    for (int i=0;i<N;i++){
        for (int j=0;j<N;j++){
            if (x[i-1]==j){
                cout<<"Q";
            }
            else cout<<".";
        }
        cout<<endl;
    }
    cout<<endl;
}


bool isValid(int k){
    for (int i=0;i<k;i++){
        if (x[i]==x[k] || abs(i-k)==abs(x[i]-x[k])) return false;
    }
    return true;
}

void next_value(int k){
    while(true){
        x[k]=(x[k]+1)%(N+1);
        if (x[k]==0) return;
        if (isValid(k)) return;
    }
}

void general_backtrack(int k){
    while(true){
        next_value(k);
        if (x[k]==0) break;
        if (k==N-1) printSolution();
        else general_backtrack(k+1);
    }
}


int main(){
    cin>>N;
    x.resize(N,0);
    general_backtrack(0);
    return 0;
}