#include <iostream>
using namespace std;

struct Node {
    int vertex, weight;
    Node* next;
    Node(int v, int w, Node* n = nullptr) : vertex(v), weight(w), next(n) {} 
};

struct MinHeapNode {
    int vertex, key;
};

void swap(MinHeapNode* a, MinHeapNode* b) {
    MinHeapNode temp = *a;
    *a = *b;
    *b = temp;
}

void minHeapify(MinHeapNode heap[], int index, int size, int pos[]) {
    int smallest = index, left = 2 * index + 1, right = 2 * index + 2;
    
    if (left < size && heap[left].key < heap[smallest].key) smallest = left;
    
    if (right < size && heap[right].key < heap[smallest].key) smallest = right;
    
    if (smallest != index) {
        pos[heap[smallest].vertex] = index;
        pos[heap[index].vertex] = smallest;
        swap(&heap[index], &heap[smallest]);
        minHeapify(heap, smallest, size, pos);
    }
}

MinHeapNode extractMin(MinHeapNode heap[], int &size, int pos[]) {
    MinHeapNode root = heap[0];
    heap[0] = heap[size - 1];
    pos[heap[0].vertex] = 0;
    size--;
    minHeapify(heap, 0, size, pos);
    return root;
}

void decreaseKey(MinHeapNode heap[], int v, int key, int pos[]) {
    int i = pos[v];
    heap[i].key = key;
    
    while (i > 0 && heap[(i - 1) / 2].key > heap[i].key) {
        pos[heap[i].vertex] = (i - 1) / 2;
        pos[heap[(i - 1) / 2].vertex] = i;
        swap(&heap[i], &heap[(i -1)/2]);
        i = (i - 1) / 2;
    }
}

void primMST(Node* graph[], int V) {
    MinHeapNode heap[V];
    int pos[V], key[V], parent[V], size = V;
    bool inMST[V];
    for (int i=0;i<V;i++) inMST[i]=false;
    
    for (int i = 0; i < V; i++) {
        key[i] = INT_MAX;
        heap[i].vertex = i;
        heap[i].key = key[i];
        pos[i] = i;
    }
    key[0] = 0;
    heap[0].key = 0;
    
    while (size > 0) {
        MinHeapNode minNode = extractMin(heap, size, pos);
        int u = minNode.vertex;
        inMST[u] = true;
        
        Node* start = graph[u];
        while (start) {
            int v = start->vertex, weight = start->weight;
            if (!inMST[v] && weight < key[v]) {
                key[v] = weight;
                parent[v] = u;
                decreaseKey(heap, v, weight, pos);
            }
            start = start->next;
        }
    }
    
    for (int i = 1; i < V; i++)
        cout << parent[i] << " - " << i << "\t" << key[i] << "\n";
}

int main() {
    int V, E;
    cin >> V >> E;
    Node* graph[V];
    for (int i=0;i<V;i++) graph[i]=nullptr;
    
    for (int i = 0; i < E; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        Node* node1 = new Node(v, w, graph[u]);
        graph[u] = node1;
        Node* node2 = new Node(u, w, graph[v]);
        graph[v] = node2;
    }
    
    primMST(graph, V);
    
    return 0;
}


/*
Input:
5 7
0 1 2
0 3 6
1 2 3
1 3 8
1 4 5
2 4 7
3 4 9
Output:
0 - 1   2
1 - 2   3
0 - 3   6
1 - 4   5
*/